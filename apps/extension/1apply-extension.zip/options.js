// src/shared/app-url.ts
var APP_BASE_URL_STORAGE_KEY = "appBaseUrl";
var DEFAULT_APP_BASE_URL = true ? "http://54.144.220.229:3000/" : "http://localhost:3000";
async function resolveAppBaseUrl() {
  const stored = await chrome.storage.local.get(APP_BASE_URL_STORAGE_KEY);
  const value = stored[APP_BASE_URL_STORAGE_KEY];
  if (typeof value === "string" && value.trim()) {
    return value.trim().replace(/\/$/, "");
  }
  return DEFAULT_APP_BASE_URL.replace(/\/$/, "");
}
async function saveAppBaseUrl(url) {
  await chrome.storage.local.set({ [APP_BASE_URL_STORAGE_KEY]: url.trim().replace(/\/$/, "") });
}
function appOriginPattern(base) {
  return `${new URL(base).origin}/*`;
}

// src/api/session.ts
async function loadSession() {
  await chrome.storage.local.remove(["deviceToken"]);
  return { appBaseUrl: await resolveAppBaseUrl() };
}
async function saveSession(_partial) {
  await chrome.storage.local.remove(["deviceToken"]);
}
async function ensureAppHostPermission(base) {
  const resolved = base ?? await resolveAppBaseUrl();
  const origins = [appOriginPattern(resolved)];
  const granted = await chrome.permissions.contains({ origins });
  if (granted) return true;
  return chrome.permissions.request({ origins });
}
async function openAppSignedIn(active = true) {
  const base = await resolveAppBaseUrl();
  const origin = new URL(base).origin;
  const existing = await chrome.tabs.query({ url: `${origin}/*` });
  const usable = existing.find((tab2) => tab2.id && tab2.url && !tab2.url.includes("/sign-in"));
  if (usable?.id) {
    if (active) await chrome.tabs.update(usable.id, { active: true });
    return usable.id;
  }
  const tab = await chrome.tabs.create({ url: `${base}/app`, active });
  if (!tab.id) throw new Error("Could not open 1-Apply.");
  await waitForTabComplete(tab.id);
  return tab.id;
}
function waitForTabComplete(tabId, timeoutMs = 2e4) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      reject(new Error("Timed out waiting for 1-Apply to load."));
    }, timeoutMs);
    function onUpdated(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    }
    void chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
        return;
      }
      chrome.tabs.onUpdated.addListener(onUpdated);
    });
  });
}

// src/api/client.ts
var ExtensionApiError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "ExtensionApiError";
  }
};
async function cookieHeaderFor(url) {
  if (!chrome.cookies?.getAll) return null;
  const cookies = await chrome.cookies.getAll({ url });
  if (!cookies.length) return null;
  return cookies.map((cookie) => `${cookie.name}=${cookie.value}`).join("; ");
}
async function directFetch(session, path, init) {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const cookie = await cookieHeaderFor(session.appBaseUrl);
  if (cookie) headers.set("Cookie", cookie);
  const response = await fetch(`${session.appBaseUrl}${path}`, {
    ...init,
    headers,
    credentials: "include"
  });
  const json = await response.json();
  if (!response.ok || json.error || json.data == null) {
    throw new ExtensionApiError(json.error?.code ?? "REQUEST_FAILED", json.error?.message ?? "Request failed.");
  }
  return json.data;
}
async function ensureBridge(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["bridge.js"] });
}
async function bridgeFetch(session, path, init) {
  const origin = new URL(session.appBaseUrl).origin;
  const tabs = await chrome.tabs.query({ url: `${origin}/*` });
  let tabId = tabs.find((tab) => tab.id)?.id;
  if (!tabId) {
    tabId = await openAppSignedIn(false);
  }
  await ensureBridge(tabId);
  const result = await chrome.tabs.sendMessage(tabId, {
    type: "BRIDGE_FETCH",
    path,
    method: init.method ?? "GET",
    body: typeof init.body === "string" ? init.body : init.body ? String(init.body) : null
  });
  if (result?.error) {
    throw new ExtensionApiError("BRIDGE_FAILED", result.error);
  }
  if (!result?.ok || result.json?.error || result.json?.data == null) {
    throw new ExtensionApiError(
      result.json?.error?.code ?? "UNAUTHENTICATED",
      result.json?.error?.message ?? "Sign in to 1-Apply in this browser, then try again."
    );
  }
  return result.json.data;
}
async function request(path, init = {}) {
  const session = await loadSession();
  const allowed = await ensureAppHostPermission();
  if (!allowed) {
    throw new ExtensionApiError(
      "HOST_PERMISSION",
      "Allow access to your 1-Apply site in the extension permission prompt."
    );
  }
  try {
    return await directFetch(session, path, init);
  } catch (error) {
    const shouldBridge = !(error instanceof ExtensionApiError) || error.code === "UNAUTHENTICATED" || error.code === "FORBIDDEN" || error.code === "REQUEST_FAILED";
    if (!shouldBridge) throw error;
    try {
      return await bridgeFetch(session, path, init);
    } catch (bridgeError) {
      if (error instanceof ExtensionApiError && (error.code === "UNAUTHENTICATED" || error.code === "FORBIDDEN")) {
        throw new ExtensionApiError(
          error.code,
          "Sign in to 1-Apply in this browser (same profile), open Options \u2192 Connect, then retry."
        );
      }
      throw bridgeError instanceof Error ? bridgeError : error;
    }
  }
}
function fetchSession() {
  return request("/api/extension/session");
}
async function connectWithWebsiteSession() {
  await saveSession();
  const allowed = await ensureAppHostPermission();
  if (!allowed) {
    throw new ExtensionApiError("HOST_PERMISSION", "Permission to access 1-Apply was denied.");
  }
  const tabId = await openAppSignedIn(true);
  await chrome.scripting.executeScript({ target: { tabId }, files: ["bridge.js"] });
  return fetchSession();
}

// src/options/options.ts
var logEl = document.getElementById("log");
var urlInput = document.getElementById("app-url");
void resolveAppBaseUrl().then((url) => {
  urlInput.value = url;
});
document.getElementById("save-url").addEventListener("click", async () => {
  const next = urlInput.value.trim();
  if (!next) {
    logEl.textContent = "Enter your 1-Apply URL (e.g. http://localhost:3000).";
    return;
  }
  try {
    await saveAppBaseUrl(next);
    logEl.textContent = `Saved ${next}. Click Connect to grant permission for that origin.`;
  } catch (error) {
    logEl.textContent = error instanceof Error ? error.message : "Could not save URL.";
  }
});
document.getElementById("connect").addEventListener("click", async () => {
  const base = await resolveAppBaseUrl();
  logEl.textContent = `Connecting to ${base}\u2026 stay signed in on 1-Apply.`;
  try {
    const session = await connectWithWebsiteSession();
    logEl.textContent = `Connected as ${session.email}. Save, scan, and fill will use this browser\u2019s 1-Apply session.`;
  } catch (error) {
    logEl.textContent = error instanceof Error ? error.message : "Could not connect.";
  }
});
//# sourceMappingURL=options.js.map
