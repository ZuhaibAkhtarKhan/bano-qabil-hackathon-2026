// src/shared/app-url.ts
var APP_BASE_URL_STORAGE_KEY = "appBaseUrl";
var DEFAULT_APP_BASE_URL = true ? "http://54.144.220.229:3000/" : "http://localhost:3000";
async function resolveAppBaseUrl() {
  const stored = await chrome.storage.local.get(APP_BASE_URL_STORAGE_KEY);
  const value = stored[APP_BASE_URL_STORAGE_KEY];
  if (typeof value === "string" && value.trim()) {
    return value.trim().replace(/\/$/, "");
  }
  return DEFAULT_APP_BASE_URL.replace(/\/$/, "");
}
function appOriginPattern(base) {
  return `${new URL(base).origin}/*`;
}

// src/api/session.ts
async function loadSession() {
  await chrome.storage.local.remove(["deviceToken"]);
  return { appBaseUrl: await resolveAppBaseUrl() };
}
async function saveSession(_partial) {
  await chrome.storage.local.remove(["deviceToken"]);
}
async function ensureAppHostPermission(base) {
  const resolved = base ?? await resolveAppBaseUrl();
  const origins = [appOriginPattern(resolved)];
  const granted = await chrome.permissions.contains({ origins });
  if (granted) return true;
  return chrome.permissions.request({ origins });
}
async function openAppSignedIn(active = true) {
  const base = await resolveAppBaseUrl();
  const origin = new URL(base).origin;
  const existing = await chrome.tabs.query({ url: `${origin}/*` });
  const usable = existing.find((tab2) => tab2.id && tab2.url && !tab2.url.includes("/sign-in"));
  if (usable?.id) {
    if (active) await chrome.tabs.update(usable.id, { active: true });
    return usable.id;
  }
  const tab = await chrome.tabs.create({ url: `${base}/app`, active });
  if (!tab.id) throw new Error("Could not open 1-Apply.");
  await waitForTabComplete(tab.id);
  return tab.id;
}
function waitForTabComplete(tabId, timeoutMs = 2e4) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      reject(new Error("Timed out waiting for 1-Apply to load."));
    }, timeoutMs);
    function onUpdated(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    }
    void chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
        return;
      }
      chrome.tabs.onUpdated.addListener(onUpdated);
    });
  });
}

// src/api/client.ts
var ExtensionApiError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "ExtensionApiError";
  }
};
async function cookieHeaderFor(url) {
  if (!chrome.cookies?.getAll) return null;
  const cookies = await chrome.cookies.getAll({ url });
  if (!cookies.length) return null;
  return cookies.map((cookie) => `${cookie.name}=${cookie.value}`).join("; ");
}
async function directFetch(session, path, init) {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const cookie = await cookieHeaderFor(session.appBaseUrl);
  if (cookie) headers.set("Cookie", cookie);
  const response = await fetch(`${session.appBaseUrl}${path}`, {
    ...init,
    headers,
    credentials: "include"
  });
  const json = await response.json();
  if (!response.ok || json.error || json.data == null) {
    throw new ExtensionApiError(json.error?.code ?? "REQUEST_FAILED", json.error?.message ?? "Request failed.");
  }
  return json.data;
}
async function ensureBridge(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["bridge.js"] });
}
async function bridgeFetch(session, path, init) {
  const origin = new URL(session.appBaseUrl).origin;
  const tabs = await chrome.tabs.query({ url: `${origin}/*` });
  let tabId = tabs.find((tab) => tab.id)?.id;
  if (!tabId) {
    tabId = await openAppSignedIn(false);
  }
  await ensureBridge(tabId);
  const result = await chrome.tabs.sendMessage(tabId, {
    type: "BRIDGE_FETCH",
    path,
    method: init.method ?? "GET",
    body: typeof init.body === "string" ? init.body : init.body ? String(init.body) : null
  });
  if (result?.error) {
    throw new ExtensionApiError("BRIDGE_FAILED", result.error);
  }
  if (!result?.ok || result.json?.error || result.json?.data == null) {
    throw new ExtensionApiError(
      result.json?.error?.code ?? "UNAUTHENTICATED",
      result.json?.error?.message ?? "Sign in to 1-Apply in this browser, then try again."
    );
  }
  return result.json.data;
}
async function request(path, init = {}) {
  const session = await loadSession();
  const allowed = await ensureAppHostPermission();
  if (!allowed) {
    throw new ExtensionApiError(
      "HOST_PERMISSION",
      "Allow access to your 1-Apply site in the extension permission prompt."
    );
  }
  try {
    return await directFetch(session, path, init);
  } catch (error) {
    const shouldBridge = !(error instanceof ExtensionApiError) || error.code === "UNAUTHENTICATED" || error.code === "FORBIDDEN" || error.code === "REQUEST_FAILED";
    if (!shouldBridge) throw error;
    try {
      return await bridgeFetch(session, path, init);
    } catch (bridgeError) {
      if (error instanceof ExtensionApiError && (error.code === "UNAUTHENTICATED" || error.code === "FORBIDDEN")) {
        throw new ExtensionApiError(
          error.code,
          "Sign in to 1-Apply in this browser (same profile), open Options \u2192 Connect, then retry."
        );
      }
      throw bridgeError instanceof Error ? bridgeError : error;
    }
  }
}
function ingestOpportunity(input) {
  return request("/api/opportunities/ingest", {
    method: "POST",
    body: JSON.stringify({
      url: input.url,
      source: "extension",
      metadata: {
        title: input.title,
        excerpt: input.excerpt,
        pageText: input.pageText,
        source: "extension"
      }
    })
  });
}
function createFillPlan(input) {
  return request(`/api/applications/${input.applicationId}/fill-plan`, {
    method: "POST",
    body: JSON.stringify({
      origin: input.origin,
      fields: input.fields,
      hazards: input.hazards ?? {}
    })
  });
}
function endFillSession(input) {
  return request(`/api/applications/${input.applicationId}/fill-session/end`, {
    method: "POST",
    body: JSON.stringify({
      reason: input.reason,
      origin: input.origin,
      fillSessionId: input.fillSessionId,
      pageUrl: input.pageUrl,
      pageText: input.pageText,
      fields: input.fields ?? []
    })
  });
}
function generateAiDraft(input) {
  return request(
    `/api/applications/${input.applicationId}/ai-draft`,
    {
      method: "POST",
      body: JSON.stringify({
        question: input.question,
        fieldKey: input.fieldKey,
        guidance: input.guidance,
        limitValue: input.limitValue ?? null,
        limitUnit: input.limitUnit ?? null
      })
    }
  );
}
function fetchSession() {
  return request("/api/extension/session");
}
function listApplications() {
  return request("/api/extension/applications");
}
function fetchDocumentFile(versionId) {
  return request(`/api/extension/documents/${versionId}`);
}
async function connectWithWebsiteSession() {
  await saveSession();
  const allowed = await ensureAppHostPermission();
  if (!allowed) {
    throw new ExtensionApiError("HOST_PERMISSION", "Permission to access 1-Apply was denied.");
  }
  const tabId = await openAppSignedIn(true);
  await chrome.scripting.executeScript({ target: { tabId }, files: ["bridge.js"] });
  return fetchSession();
}

// src/background/service-worker.ts
var FILL_SESSION_KEY = "fillSession";
var SESSION_TTL_MS = 4 * 60 * 60 * 1e3;
var autoFillInFlight = /* @__PURE__ */ new Set();
var fillHaltGeneration = 0;
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab.");
  return tab;
}
function tabOrigin(tab) {
  if (!tab.url) throw new Error("The active tab has no URL.");
  const parsed = new URL(tab.url);
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("Open a public http(s) page first.");
  }
  if (parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1" || parsed.hostname === "::1") {
    throw new Error("Local pages cannot be ingested or filled.");
  }
  return parsed.origin;
}
async function ensureHostAccess(origin) {
  const origins = [`${origin}/*`];
  const already = await chrome.permissions.contains({ origins });
  if (already) return;
  throw new Error(
    "Site access is missing. Click Fill/Save in the 1-Apply popup once and allow access when Chrome asks."
  );
}
async function saveFillSession(session) {
  await chrome.storage.local.set({ [FILL_SESSION_KEY]: session });
}
async function loadFillSession() {
  const data = await chrome.storage.local.get([FILL_SESSION_KEY]);
  const session = data[FILL_SESSION_KEY];
  if (!session?.enabled || !session.applicationId) return null;
  if (Date.now() - session.updatedAt > SESSION_TTL_MS) {
    await chrome.storage.local.remove(FILL_SESSION_KEY);
    return null;
  }
  return session;
}
async function ensureContentScript(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
}
async function sendToTab(tabId, message) {
  await ensureContentScript(tabId);
  return chrome.tabs.sendMessage(tabId, message);
}
async function loadAttachedFiles(mappings) {
  const files = /* @__PURE__ */ new Map();
  const versionIds = /* @__PURE__ */ new Set();
  for (const mapping of mappings) {
    if (mapping.fieldType !== "file") continue;
    if (mapping.attachment?.versionId) versionIds.add(mapping.attachment.versionId);
    if (mapping.proposedValue) versionIds.add(mapping.proposedValue);
    for (const option of mapping.options ?? []) {
      if (option.value) versionIds.add(option.value);
    }
  }
  await Promise.all(
    Array.from(versionIds).slice(0, 6).map(async (versionId) => {
      try {
        const file = await fetchDocumentFile(versionId);
        files.set(versionId, {
          versionId: file.versionId,
          filename: file.filename,
          mimeType: file.mimeType,
          base64: file.base64
        });
      } catch {
      }
    })
  );
  return files;
}
async function applyMappingsToTab(input) {
  const mappings = input.mappings.filter(
    (item) => item.approvalState !== "blocked" && !item.sensitive && item.memoryPath !== "Blocked"
  );
  const files = await loadAttachedFiles(mappings);
  const highlightKeys = input.highlightKeys ?? input.mappings.map((item) => item.fieldKey);
  return sendToTab(input.tabId, {
    type: "APPLY_SUGGESTIONS",
    origin: input.origin,
    applicationId: input.applicationId,
    highlightKeys,
    autoContinue: true,
    resumeFill: Boolean(input.resumeFill),
    mappings: mappings.map((item) => {
      const versionId = item.attachment?.versionId || item.proposedValue;
      const file = versionId ? files.get(versionId) : void 0;
      const aiAnswerable = Boolean(item.aiAnswerable);
      return {
        fieldKey: item.fieldKey,
        label: item.label,
        value: aiAnswerable ? "" : item.fieldType === "file" ? versionId || "" : item.proposedValue,
        type: item.fieldType,
        showChip: true,
        aiAnswerable,
        options: item.options?.length ? item.options : item.proposedValue && !aiAnswerable ? [{ value: item.proposedValue, label: item.memoryPath, source: item.source }] : [],
        file: file ? {
          versionId: file.versionId,
          filename: file.filename,
          mimeType: file.mimeType,
          base64: file.base64
        } : item.attachment ? {
          versionId: item.attachment.versionId,
          filename: item.attachment.filename,
          mimeType: item.attachment.mimeType,
          base64: ""
        } : null
      };
    })
  });
}
async function continueFillOnTab(tabId) {
  if (autoFillInFlight.has(tabId)) return { ok: false, reason: "busy" };
  const session = await loadFillSession();
  if (!session) return { ok: false, reason: "no-session" };
  const haltAtStart = fillHaltGeneration;
  const tab = await chrome.tabs.get(tabId);
  let origin;
  try {
    origin = tabOrigin(tab);
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : "bad-tab" };
  }
  if (origin !== session.origin) return { ok: false, reason: "origin-mismatch" };
  autoFillInFlight.add(tabId);
  try {
    if (fillHaltGeneration !== haltAtStart) return { ok: false, reason: "stopped" };
    await ensureHostAccess(origin).catch(() => void 0);
    await ensureContentScript(tabId);
    let inventory = null;
    for (let attempt = 0; attempt < 5; attempt += 1) {
      if (fillHaltGeneration !== haltAtStart || !await loadFillSession()) {
        return { ok: false, reason: "stopped" };
      }
      if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 450 * attempt));
      try {
        inventory = await sendToTab(tabId, { type: "INVENTORY" });
      } catch {
        inventory = null;
      }
      if (inventory?.fields?.length) break;
    }
    if (!inventory?.fields?.length) return { ok: false, reason: "no-fields" };
    if (fillHaltGeneration !== haltAtStart || !await loadFillSession()) {
      return { ok: false, reason: "stopped" };
    }
    const plan = await createFillPlan({
      applicationId: session.applicationId,
      origin,
      fields: inventory.fields,
      hazards: inventory.hazards
    });
    if (fillHaltGeneration !== haltAtStart || !await loadFillSession()) {
      return { ok: false, reason: "stopped" };
    }
    const result = await applyMappingsToTab({
      tabId,
      origin,
      applicationId: session.applicationId,
      mappings: plan.mappings,
      highlightKeys: inventory.fields.map((field) => field.key),
      resumeFill: false
    });
    if (fillHaltGeneration !== haltAtStart || result.stopped || !await loadFillSession()) {
      return { ok: false, reason: "stopped" };
    }
    await saveFillSession({
      ...session,
      tabId,
      origin,
      updatedAt: Date.now(),
      enabled: true,
      fillSessionId: plan.fillSessionId || session.fillSessionId
    });
    const filled = result.filled?.filter((item) => item.filled).length ?? 0;
    return { ok: true, filled };
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : "continue-failed" };
  } finally {
    autoFillInFlight.delete(tabId);
  }
}
async function clearFillSession(tabId, reason = "stopped") {
  const session = await loadFillSession();
  if (!session) {
    fillHaltGeneration += 1;
    if (tabId != null) {
      try {
        await sendToTab(tabId, { type: "STOP_AUTO_CONTINUE" });
      } catch {
      }
    }
    return;
  }
  if (tabId != null && session.tabId !== tabId) return;
  fillHaltGeneration += 1;
  await syncFillSessionEnd(session, reason);
  await chrome.storage.local.remove(FILL_SESSION_KEY);
  if (session.tabId) {
    try {
      await sendToTab(session.tabId, { type: "STOP_AUTO_CONTINUE" });
    } catch {
    }
  }
}
async function captureFilledState(tabId) {
  try {
    return await sendToTab(tabId, { type: "CAPTURE_FILLED_STATE" });
  } catch {
    return null;
  }
}
async function syncFillSessionEnd(session, reason) {
  let captured = null;
  if (session.tabId) {
    captured = await captureFilledState(session.tabId);
  }
  try {
    await endFillSession({
      applicationId: session.applicationId,
      reason,
      origin: captured?.origin || session.origin,
      fillSessionId: session.fillSessionId,
      pageUrl: captured?.pageUrl,
      pageText: captured?.pageText,
      fields: captured?.fields ?? []
    });
  } catch {
  }
}
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status && info.status !== "complete" && !info.url) return;
  void (async () => {
    const session = await loadFillSession();
    if (!session || session.tabId !== tabId) return;
    if (info.status === "loading") return;
    try {
      const tab = await chrome.tabs.get(tabId);
      if (!tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("about:")) return;
      const origin = tabOrigin(tab);
      if (origin !== session.origin) {
        if (info.status === "complete") await clearFillSession(tabId, "origin_left");
        return;
      }
    } catch {
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
    await continueFillOnTab(tabId);
  })();
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void clearFillSession(tabId, "tab_closed");
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const task = (async () => {
    if (message?.type === "SESSION") return fetchSession();
    if (message?.type === "CONNECT_WEBSITE") return connectWithWebsiteSession();
    if (message?.type === "LIST_APPLICATIONS") return listApplications();
    if (message?.type === "FILL_SESSION_STATUS") {
      const session = await loadFillSession();
      if (!session) return { active: false };
      return { active: true, origin: session.origin, tabId: session.tabId, applicationId: session.applicationId };
    }
    if (message?.type === "GENERATE_AI_DRAFT") {
      return generateAiDraft({
        applicationId: String(message.applicationId ?? ""),
        question: String(message.question ?? ""),
        fieldKey: message.fieldKey ? String(message.fieldKey) : void 0,
        guidance: message.guidance ? String(message.guidance) : void 0,
        limitValue: typeof message.limitValue === "number" ? message.limitValue : null,
        limitUnit: message.limitUnit === "words" || message.limitUnit === "characters" ? message.limitUnit : null
      });
    }
    if (message?.type === "AUTO_CONTINUE_FILL") {
      const tabId = sender.tab?.id;
      if (!tabId) throw new Error("No tab for auto-continue.");
      return continueFillOnTab(tabId);
    }
    if (message?.type === "STOP_FILL_SESSION") {
      fillHaltGeneration += 1;
      const session = await loadFillSession();
      if (session) {
        await syncFillSessionEnd(session, "stopped");
      }
      await chrome.storage.local.remove(FILL_SESSION_KEY);
      const tabId = session?.tabId ?? (await activeTab().catch(() => null))?.id;
      if (tabId) {
        try {
          await sendToTab(tabId, { type: "STOP_AUTO_CONTINUE" });
        } catch {
        }
      }
      return { ok: true };
    }
    if (message?.type === "ATTACH_FILE_ALL_FRAMES") {
      const tab = await activeTab();
      if (!tab.id) throw new Error("No active tab.");
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: (file) => {
          const wanted = (file.filename || "").trim().toLowerCase().replace(/^.*[\\/]/, "");
          const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
          let already = false;
          for (const input of inputs) {
            const names = Array.from(input.files ?? []).map((item) => item.name.toLowerCase());
            if (names.length && (!wanted || names.some((name) => name === wanted || name.endsWith(wanted)))) {
              already = true;
            }
          }
          const pageText = (document.body?.innerText ?? "").toLowerCase();
          if (wanted && pageText.includes(wanted) && /uploaded|selected|attached|remove file/i.test(pageText)) {
            already = true;
          }
          if (already) return true;
          const binary = atob(file.base64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
          const blob = new File([bytes], file.filename || "document.pdf", {
            type: file.mimeType || "application/pdf"
          });
          let ok = false;
          for (const input of inputs) {
            const transfer = new DataTransfer();
            transfer.items.add(blob);
            input.files = transfer.files;
            input.dispatchEvent(new Event("input", { bubbles: true }));
            input.dispatchEvent(new Event("change", { bubbles: true }));
            if ((input.files?.length ?? 0) > 0) ok = true;
          }
          return ok;
        },
        args: [message.file]
      });
      return { ok: results.some((item) => item.result) };
    }
    if (message?.type === "SAVE_PAGE") {
      const tab = await activeTab();
      if (!tab.id) throw new Error("No active tab.");
      const origin = tabOrigin(tab);
      await ensureHostAccess(origin);
      const meta = await sendToTab(tab.id, { type: "GET_PAGE_META" });
      const pageUrl = meta.url || tab.url || "";
      if (new URL(pageUrl).origin !== origin) {
        throw new Error("Page origin changed. Refresh and try again.");
      }
      return ingestOpportunity({
        url: pageUrl,
        title: meta.title || tab.title || void 0,
        excerpt: meta.excerpt,
        pageText: meta.pageText || meta.excerpt
      });
    }
    if (message?.type === "SCAN_FORM") {
      const tab = await activeTab();
      if (!tab.id) throw new Error("No active tab.");
      const origin = tabOrigin(tab);
      await ensureHostAccess(origin);
      const inventory = await sendToTab(tab.id, { type: "INVENTORY" });
      return { ...inventory, tabId: tab.id, origin };
    }
    if (message?.type === "CREATE_FILL_PLAN") {
      return createFillPlan({
        applicationId: String(message.applicationId),
        origin: String(message.origin ?? ""),
        fields: message.fields,
        hazards: message.hazards
      });
    }
    if (message?.type === "APPLY_SUGGESTIONS" || message?.type === "APPLY_SUGGESTIONS" || message?.type === "FILL" || message?.type === "FILL_APPROVED") {
      const tab = await activeTab();
      if (!tab.id) throw new Error("No active tab.");
      const origin = tabOrigin(tab);
      const expectedOrigin = String(message.origin ?? "");
      const expectedTabId = Number(message.tabId);
      if (!expectedOrigin || origin !== expectedOrigin) {
        throw new Error("Page origin changed. Try Fill from memory again.");
      }
      if (expectedTabId && expectedTabId !== tab.id) {
        throw new Error("Active tab changed. Try Fill from memory again.");
      }
      await ensureHostAccess(origin);
      const applicationId = String(message.applicationId ?? "");
      const fillSessionId = message.fillSessionId ? String(message.fillSessionId) : void 0;
      if (applicationId) {
        fillHaltGeneration += 1;
        await saveFillSession({
          applicationId,
          origin,
          tabId: tab.id,
          enabled: true,
          updatedAt: Date.now(),
          fillSessionId
        });
      }
      return applyMappingsToTab({
        tabId: tab.id,
        origin,
        applicationId,
        mappings: message.mappings,
        highlightKeys: Array.isArray(message.highlightKeys) ? message.highlightKeys : void 0,
        resumeFill: true
      });
    }
    throw new Error("Unknown message.");
  })();
  task.then(sendResponse).catch((error) => sendResponse({ error: error.message }));
  return true;
});
//# sourceMappingURL=background.js.map
