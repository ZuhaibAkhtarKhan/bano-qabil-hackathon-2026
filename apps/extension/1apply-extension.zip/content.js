// ../../packages/form-engine/src/types.ts
function fieldSignals(field) {
  return [field.label, field.name, field.id, field.placeholder, field.ariaLabel, field.nearbyText, field.type, field.autocomplete].filter(Boolean).join(" ").toLowerCase();
}

// ../../packages/form-engine/src/safety.ts
var PROTECTED = [
  /captcha/i,
  /recaptcha/i,
  /hcaptcha/i,
  /turnstile/i,
  /\bsubmit\b/i,
  /signature/i,
  /e-?sign/i,
  /attest/i,
  /payment/i,
  /credit.?card/i,
  /card.?number/i,
  /cvv/i,
  /password/i,
  /\bmfa\b/i,
  /\b2fa\b/i,
  /\botp\b/i,
  /one.?time/i,
  /ssn|social.?security/i
];
var SENSITIVE = [
  /citizenship/i,
  /work.?authorization/i,
  /visa.?status/i,
  /authorized.?to.?work/i,
  /race|ethnicity|hispanic/i,
  /gender|sex\b/i,
  /disability|disabled/i,
  /veteran/i,
  /criminal|conviction|felony/i,
  /demographic/i,
  /date of birth|birthdate|dob\b/i,
  /passport|national.?id/i,
  /ssn|social.?security/i,
  /legal.?name.?attestation/i
];
function isProtectedControl(field) {
  const haystack = `${field.name} ${field.id ?? ""} ${field.label} ${field.placeholder ?? ""} ${field.ariaLabel ?? ""} ${field.nearbyText ?? ""} ${field.type} ${field.role ?? ""}`;
  if (PROTECTED.some((pattern) => pattern.test(haystack))) return true;
  if (field.type === "submit" || field.type === "password" || field.type === "button") return true;
  if (field.role === "button" && /submit|pay|sign|register/i.test(field.label)) return true;
  return false;
}
function isSensitiveField(field) {
  const haystack = `${field.name} ${field.id ?? ""} ${field.label} ${field.placeholder ?? ""} ${field.ariaLabel ?? ""} ${field.nearbyText ?? ""}`;
  return SENSITIVE.some((pattern) => pattern.test(haystack));
}
function fillTargetAllowed(fieldKey2, type) {
  return !isProtectedControl({ name: fieldKey2, label: fieldKey2, type, id: fieldKey2 });
}
function isForbiddenFillAction(action) {
  return action === "submit" || action === "clickSubmit" || action === "bypassCaptcha" || action === "createAccount";
}

// ../../packages/form-engine/src/hazards.ts
var CAPTCHA_SELECTORS = [
  ".g-recaptcha",
  ".h-captcha",
  ".cf-turnstile",
  "iframe[src*='recaptcha']",
  "iframe[src*='hcaptcha']",
  "iframe[src*='turnstile']",
  "[data-sitekey]",
  "#captcha",
  "[name='g-recaptcha-response']"
];
function detectCaptcha(root2, pageText = "") {
  const html = `${pageText} ${"outerHTML" in root2 && typeof root2.outerHTML === "string" ? root2.outerHTML : ""}`.toLowerCase();
  let vendor = null;
  if (root2.querySelector?.(".g-recaptcha, iframe[src*='recaptcha'], [name='g-recaptcha-response']") || /recaptcha/.test(html)) {
    vendor = "reCAPTCHA";
  } else if (root2.querySelector?.(".h-captcha, iframe[src*='hcaptcha']") || /hcaptcha|h-captcha/.test(html)) {
    vendor = "hCaptcha";
  } else if (root2.querySelector?.(".cf-turnstile, iframe[src*='turnstile']") || /turnstile/.test(html)) {
    vendor = "Cloudflare Turnstile";
  } else if (root2.querySelector?.(CAPTCHA_SELECTORS.join(",")) || /\bi'?m not a robot\b/.test(html) || /\bcaptcha\b/.test(html)) {
    vendor = "CAPTCHA";
  }
  if (!vendor) {
    return { captcha: false, captchaVendor: null, captchaMessage: null };
  }
  return {
    captcha: true,
    captchaVendor: vendor,
    captchaMessage: `${vendor} detected. Autofill is paused for the challenge. Human action is required \u2014 1-Apply never bypasses CAPTCHA. Nearby safe fields may still be filled after you approve them.`
  };
}
function detectAccountCreation(root2, pageText = "") {
  const text = `${pageText} ${root2.textContent ?? ""}`.toLowerCase();
  const password = root2.querySelector?.("input[type='password']");
  const email = root2.querySelector?.("input[type='email'], input[name*='email' i]");
  const createCopy = /create (your )?account|sign up|register( now)?|join now|open an account/.test(text);
  if (password && email && createCopy) {
    return {
      accountCreation: true,
      accountMessage: "This page looks like account creation. 1-Apply will not create host accounts, fill passwords, or bypass account-security checks. Sign in or register yourself, then reopen the extension on the application form."
    };
  }
  return { accountCreation: false, accountMessage: null };
}
function detectUnsupportedForm(fields, hazards) {
  if (hazards.accountCreation) {
    return {
      unsupported: true,
      unsupportedReason: "Account creation cannot be automated. Continue manually after you have a host account."
    };
  }
  const fillable = fields.filter((field) => field.type !== "file" && field.type !== "password");
  if (fillable.length === 0) {
    return {
      unsupported: true,
      unsupportedReason: "No standard fields could be mapped on this page. Continue the application manually in the host form."
    };
  }
  return { unsupported: false, unsupportedReason: null };
}
function inspectPage(root2, pageText = "", fields = []) {
  const captcha = detectCaptcha(root2, pageText);
  const account = detectAccountCreation(root2, pageText);
  const unsupported = detectUnsupportedForm(fields, { captcha: captcha.captcha, accountCreation: account.accountCreation });
  const hasSubmitControl = Boolean(
    root2.querySelector?.("button[type='submit'], input[type='submit'], button[name*='submit' i], [role='button']")
  );
  return {
    ...captcha,
    ...account,
    ...unsupported,
    hasSubmitControl
  };
}

// ../../packages/form-engine/src/question-label.ts
function isMachineFieldToken(value) {
  const text = (value ?? "").trim();
  if (!text) return true;
  if (text.length >= 20 && /^[a-f0-9_-]+$/i.test(text)) return true;
  if (/^[0-9a-f]{8,}$/i.test(text)) return true;
  if (/^(entry\.\d+|wf-\d+|form_field_|field_|input_|ctl\d+)/i.test(text)) return true;
  if (/^(csrf|xsrf|authenticity|recaptcha|g-recaptcha|utm_|tracking|session)/i.test(text)) return true;
  if (/^[a-z0-9]+(?:[-_][a-z0-9]+){0,4}$/i.test(text) && !/[? ]/.test(text) && text.length <= 40) {
    return !/\b(name|email|phone|city|country|resume|linkedin|github|portfolio|address|birth|university|school|degree)\b/i.test(
      text.replace(/[-_]/g, " ")
    );
  }
  return false;
}
function collapseWhitespace(value) {
  return value.replace(/\s+/g, " ").trim();
}
var REQUIRED_WORD = "required|mandatory|obligatory|obligatoriskt|obligatorisk|obligatoire|obligatorio|obrigat[o\xF3]rio|obbligatorio|pflichtfeld|erforderlich|verpflichtend|verplicht|pakollinen|wymagane|n[e\xE9]cessaire|must\\s+answer|must\\s+fill";
function stripFormSyntaxDecorators(value) {
  let text = value;
  text = text.replace(new RegExp(`\\*{1,6}\\s*(?:${REQUIRED_WORD})\\s*\\*{0,6}`, "gi"), " ");
  text = text.replace(new RegExp(`[\\[\\(]\\s*(?:${REQUIRED_WORD})\\s*[\\]\\)]`, "gi"), " ");
  text = text.replace(new RegExp(`(?:^|[\\s:;\\-\u2013\u2014])(?:${REQUIRED_WORD})\\s*$`, "gi"), " ");
  text = text.replace(new RegExp(`^(?:${REQUIRED_WORD})\\s*[:.\\-\u2013\u2014]?\\s*`, "gi"), " ");
  text = text.replace(/\*{1,6}/g, " ");
  text = text.replace(/\s*[•·]\s*$/g, " ");
  if (new RegExp(`^(?:this\\s+is\\s+a\\s+)?(?:${REQUIRED_WORD})(?:\\s+question)?\\.?$`, "i").test(text.trim())) {
    return "";
  }
  return collapseWhitespace(text);
}
function humanizeFieldToken(value) {
  const cleaned = value.replace(/^(entry\.\d+|listitem:|labelledby:|aria:|radio:|pos:)/i, "").replace(/[_\-.]+/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/\s+/g, " ").trim();
  if (!cleaned) return value;
  return cleaned.replace(/\b\w/g, (ch) => ch.toUpperCase()).slice(0, 120);
}
function humanQuestionLabel(field) {
  const candidates = [field.label, field.nearbyText, field.ariaLabel, field.placeholder].map((item) => stripFormSyntaxDecorators(collapseWhitespace(item ?? ""))).filter(Boolean);
  for (const candidate of candidates) {
    if (!isMachineFieldToken(candidate) && candidate.length >= 2) {
      return candidate.slice(0, 200);
    }
  }
  for (const raw of [field.name, field.key, field.id]) {
    const token = collapseWhitespace(raw ?? "");
    if (!token || isMachineFieldToken(token)) continue;
    return humanizeFieldToken(token);
  }
  for (const raw of [field.name, field.key]) {
    const token = collapseWhitespace(raw ?? "");
    if (!token) continue;
    if (/^[a-f0-9]{16,}$/i.test(token)) continue;
    return humanizeFieldToken(token);
  }
  return "Form question";
}
function isNoiseFormField(field) {
  const blob = [field.name, field.id, field.key, field.label, field.ariaLabel].join(" ").toLowerCase();
  if (field.inputType === "hidden") return true;
  if (/csrf|xsrf|authenticity_token|recaptcha|honeypot|botcheck|utm_|tracking[_-]?id|session[_-]?id/i.test(blob)) {
    return true;
  }
  if (/share[-_]?link|copy[-_]?link|invite[-_]?token/i.test(blob)) {
    const question2 = humanQuestionLabel(field);
    if (question2 === "Form question" || isMachineFieldToken(question2) || /^share\s*link$/i.test(question2)) {
      return true;
    }
  }
  const question = humanQuestionLabel(field);
  if (question === "Form question" && isMachineFieldToken(field.key) && isMachineFieldToken(field.name || field.id)) {
    return true;
  }
  return false;
}

// ../../packages/form-engine/src/detect.ts
var APPLY_FIELD_ATTR = "data-1apply-key";
var APPLY_EMPTY_ATTR = "data-1apply-empty";
var APPLY_HOST_ATTR = "data-1apply-host-card";
var TEXTUAL = /* @__PURE__ */ new Set(["text", "email", "tel", "search", "password", ""]);
function attr(el, name) {
  return (el.getAttribute(name) ?? "").trim();
}
function normalizeType(tag, inputType, multiple) {
  const type = inputType.toLowerCase();
  if (tag === "textarea") return "textarea";
  if (tag === "select") return multiple ? "multi-select" : "select";
  if (type === "radio") return "radio";
  if (type === "checkbox") return "checkbox";
  if (type === "date" || type === "datetime-local" || type === "month") return "date";
  if (type === "number" || type === "range") return "number";
  if (type === "url") return "url";
  if (type === "file") return "file";
  if (type === "email" || type === "tel" || TEXTUAL.has(type)) return "text";
  return "text";
}
function cssEscape(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
function stamp(el, key) {
  if (!el) return;
  el.setAttribute(APPLY_FIELD_ATTR, key);
}
function stampCard(item, key) {
  if (!item) return;
  item.setAttribute(APPLY_FIELD_ATTR, key);
  item.setAttribute(APPLY_HOST_ATTR, "1");
}
function isMarkedRequired(item, heading, label, control) {
  if (/required|obligatorisk|mandatory|pflichtfeld|erforderlich|\*/i.test(label)) return true;
  if (heading && /required|obligatorisk|mandatory|pflichtfeld|erforderlich|\*/i.test(heading.textContent ?? "")) {
    return true;
  }
  if (control && (attr(control, "aria-required") === "true" || control.required)) return true;
  const header = heading?.parentElement ?? item;
  if (header.querySelector?.('[aria-label*="Required" i], [aria-label*="required" i], [aria-label*="Obligatorisk" i]')) return true;
  const headerText = (header.textContent ?? "").slice(0, 160);
  if (/\*/.test(headerText) || /\b(?:required|obligatorisk|mandatory)\b/i.test(headerText)) return true;
  const blob = `${label} ${item.textContent ?? ""} ${attr(control ?? item, "aria-label")}`;
  if (/record\s+.+\s+as the email to be included with my response/i.test(blob)) return true;
  return false;
}
function cleanQuestionText(value) {
  return stripFormSyntaxDecorators((value ?? "").replace(/\s+/g, " ").trim()).slice(0, 200);
}
function looksLikeQuestionText(value) {
  if (!value || value.length < 2) return false;
  if (/^[a-f0-9_-]{16,}$/i.test(value)) return false;
  if (/^(entry\.\d+|wf-\d+)/i.test(value)) return false;
  return true;
}
function labelFor(el, root2) {
  const id = attr(el, "id");
  if (id && "querySelector" in root2) {
    const labelled = root2.querySelector(`label[for="${cssEscape(id)}"]`);
    const text = cleanQuestionText(labelled?.textContent);
    if (looksLikeQuestionText(text)) return text;
  }
  const wrapped = el.closest("label");
  if (wrapped?.textContent) {
    const clone = wrapped.cloneNode(true);
    for (const control of Array.from(clone.querySelectorAll("input, textarea, select, button"))) control.remove();
    const text = cleanQuestionText(clone.textContent);
    if (looksLikeQuestionText(text)) return text;
  }
  const labelledBy = attr(el, "aria-labelledby");
  if (labelledBy && "getElementById" in root2) {
    const parts = labelledBy.split(/\s+/).map((token) => cleanQuestionText(root2.getElementById?.(token)?.textContent)).filter((text) => looksLikeQuestionText(text));
    if (parts.length) return parts.join(" ").slice(0, 200);
  }
  const item = el.closest('[role="listitem"]');
  const heading = item?.querySelector('[role="heading"]');
  const headingText = cleanQuestionText(heading?.textContent);
  if (looksLikeQuestionText(headingText)) return headingText;
  const aria = cleanQuestionText(attr(el, "aria-label"));
  if (looksLikeQuestionText(aria)) return aria;
  const host = el.closest(
    "[data-question], [data-field-label], .form-group, .form-field, .field, .question, .application-question, .freebirdFormviewerComponentsQuestionBaseRoot, fieldset, [role='group']"
  );
  if (host && !["form", "body", "html", "main", "section"].includes(host.tagName.toLowerCase())) {
    for (const selector of [
      "[data-question]",
      "[data-field-label]",
      ".question-title",
      ".form-label",
      ".field-label",
      "label",
      "legend",
      "h1",
      "h2",
      "h3",
      "h4",
      '[role="heading"]',
      "p",
      "span"
    ]) {
      const node = host.querySelector(selector);
      if (!node || node === el || el.contains(node)) continue;
      const text = cleanQuestionText(
        node.getAttribute?.("data-question") || node.getAttribute?.("data-field-label") || node.textContent
      );
      if (looksLikeQuestionText(text) && text.length >= 3 && text.length <= 200) return text;
    }
  }
  let sibling = el.previousElementSibling;
  for (let i = 0; i < 4 && sibling; i += 1) {
    if (!isLocalQuestionNode(sibling)) {
      sibling = sibling.previousElementSibling;
      continue;
    }
    const text = cleanQuestionText(
      sibling.getAttribute?.("data-question") || sibling.getAttribute?.("aria-label") || sibling.textContent
    );
    if (looksLikeQuestionText(text) && text.length >= 2 && text.length <= 200) return text;
    sibling = sibling.previousElementSibling;
  }
  return "";
}
function nearbyText(el) {
  const bits = [];
  const item = el.closest('[role="listitem"]');
  if (item) {
    const heading = item.querySelector('[role="heading"]');
    if (heading?.textContent) bits.push(cleanQuestionText(heading.textContent));
    const describedBy = attr(el, "aria-describedby");
    if (describedBy && el.ownerDocument) {
      for (const token of describedBy.split(/\s+/)) {
        const node = el.ownerDocument.getElementById(token);
        if (node?.textContent) bits.push(cleanQuestionText(node.textContent).slice(0, 80));
      }
    }
    const description = item.querySelector('[role="text"], .freebirdFormviewerComponentsQuestionBaseDescription');
    if (description?.textContent) bits.push(cleanQuestionText(description.textContent).slice(0, 160));
    return bits.filter(Boolean).join(" ").slice(0, 240);
  }
  const prev = el.previousElementSibling;
  if (prev && isLocalQuestionNode(prev)) {
    bits.push(cleanQuestionText(prev.textContent));
  }
  const parent = el.parentElement;
  if (parent && isTightQuestionHost(parent)) {
    const dt = parent.previousElementSibling;
    if (dt && dt.tagName.toLowerCase() === "dt") bits.push(cleanQuestionText(dt.textContent));
    const title = parent.querySelector("label, legend, [role='heading'], .question-title, .field-label");
    if (title && !el.contains(title) && title !== el) bits.push(cleanQuestionText(title.textContent));
  }
  const group = el.closest("fieldset, [role='group'], .form-group, .field, .question");
  if (group && isTightQuestionHost(group)) {
    const legend = group.querySelector("legend, [role='heading'], label, .question-title");
    if (legend && !el.contains(legend)) bits.push(cleanQuestionText(legend.textContent));
  }
  return bits.filter(Boolean).join(" ").slice(0, 240);
}
function isTightQuestionHost(el) {
  return !["form", "body", "html", "main", "section", "article", "div"].includes(el.tagName.toLowerCase()) || /form-group|form-field|field|question|application-question|listitem/i.test(
    `${el.className} ${el.getAttribute("role") ?? ""} ${el.getAttribute("data-question") ?? ""}`
  );
}
function isLocalQuestionNode(el) {
  const tag = el.tagName.toLowerCase();
  if (["label", "legend", "p", "span", "h1", "h2", "h3", "h4", "h5", "h6", "strong", "em"].includes(tag)) {
    return true;
  }
  if (["input", "textarea", "select", "button", "form"].includes(tag)) return false;
  if (el.querySelector("input, textarea, select, button, [role='listbox'], [role='textbox']")) return false;
  const text = cleanQuestionText(el.textContent);
  return looksLikeQuestionText(text) && text.length <= 200;
}
function optionLabel(el) {
  const aria = attr(el, "aria-label");
  if (aria) return aria;
  const dataValue = attr(el, "data-value");
  if (dataValue) return dataValue;
  const labelledBy = attr(el, "aria-labelledby");
  if (labelledBy && el.ownerDocument) {
    const text = labelledBy.split(/\s+/).map((token) => el.ownerDocument?.getElementById(token)?.textContent?.trim() ?? "").filter(Boolean).join(" ");
    if (text) return text;
  }
  const wrap = el.closest("label");
  if (wrap) {
    const clone = wrap.cloneNode(true);
    for (const control of Array.from(clone.querySelectorAll("input, textarea, select"))) control.remove();
    const text = clone.textContent?.trim() ?? "";
    if (text) return text;
  }
  const span = el.querySelector("span, .docssharedWizToggleLabeledLabelText");
  if (span?.textContent?.trim()) return span.textContent.trim().slice(0, 160);
  return (el.value || el.textContent || "").trim().slice(0, 160);
}
function selectOptions(el) {
  if (el.tagName.toLowerCase() !== "select") return [];
  return Array.from(el.querySelectorAll("option")).map((option) => (option.textContent ?? "").trim()).filter(Boolean);
}
function choiceOptions(el, inputType, root2) {
  if (el.tagName.toLowerCase() === "select") return selectOptions(el);
  if (inputType !== "radio" && inputType !== "checkbox") return [];
  const item = el.closest('[role="listitem"]');
  if (item) {
    const roleRadios = Array.from(item.querySelectorAll('[role="radio"], [role="checkbox"]'));
    if (roleRadios.length) return roleRadios.map((node) => optionLabel(node)).filter(Boolean);
    return Array.from(item.querySelectorAll(`input[type="${inputType}"]`)).map((node) => optionLabel(node)).filter(Boolean);
  }
  const name = attr(el, "name");
  if (name && "querySelectorAll" in root2) {
    return Array.from(root2.querySelectorAll(`input[type="${inputType}"][name="${cssEscape(name)}"]`)).map((node) => optionLabel(node)).filter(Boolean);
  }
  return [optionLabel(el)].filter(Boolean);
}
function listitemKey(item, index) {
  const heading = item.querySelector('[role="heading"]');
  const headingId = heading?.id || attr(heading ?? item, "id");
  if (headingId) return `listitem:${headingId}`;
  const labelledBy = attr(item.querySelector("[aria-labelledby]") ?? item, "aria-labelledby");
  if (labelledBy) return `listitem:${labelledBy}`;
  return `listitem:pos:${index}`;
}
function existingListitemKey(el, root2) {
  const item = el.closest('[role="listitem"]');
  if (!item) return null;
  const items = Array.from(root2.querySelectorAll?.('[role="listitem"]') ?? []);
  const index = items.indexOf(item);
  return listitemKey(item, index >= 0 ? index : 0);
}
function pushField(fields, field) {
  const next = { ...field, signals: "" };
  next.label = humanQuestionLabel(next);
  next.signals = fieldSignals(next);
  if (isNoiseFormField(next)) return;
  fields.push(next);
}
function inventoryGoogleFormsListitems(root2, seen) {
  const fields = [];
  const items = Array.from(root2.querySelectorAll?.('[role="listitem"]') ?? []);
  for (const [index, item] of items.entries()) {
    const key = listitemKey(item, index);
    if (seen.has(key)) continue;
    const heading = item.querySelector('[role="heading"]');
    const label = cleanQuestionText(heading?.textContent) || labelFor(item, root2);
    const textBlob = `${label} ${item.textContent ?? ""}`.toLowerCase();
    const listbox = item.querySelector('[role="listbox"]');
    if (listbox) {
      seen.add(key);
      const options = Array.from(item.querySelectorAll('[role="option"]')).map((node) => optionLabel(node)).filter(Boolean);
      stamp(listbox, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: "",
        id: heading?.id ?? "",
        label,
        placeholder: "Choose",
        ariaLabel: attr(listbox, "aria-label"),
        nearbyText: label,
        type: "select",
        inputType: "listbox",
        options,
        required: isMarkedRequired(item, heading, label, listbox),
        autocomplete: ""
      });
      continue;
    }
    const roleRadios = Array.from(item.querySelectorAll('[role="radio"]'));
    if (roleRadios.length > 0) {
      seen.add(key);
      const options = roleRadios.map((node) => optionLabel(node)).filter(Boolean);
      for (const radio of roleRadios) stamp(radio, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: "",
        id: heading?.id ?? "",
        label,
        placeholder: "",
        ariaLabel: "",
        nearbyText: label,
        type: "radio",
        inputType: "radio",
        options,
        required: isMarkedRequired(item, heading, label),
        autocomplete: ""
      });
      continue;
    }
    const roleChecks = Array.from(item.querySelectorAll('[role="checkbox"]'));
    if (roleChecks.length > 1 || roleChecks.length === 1 && /select all|choose all|which of the following/i.test(textBlob)) {
      seen.add(key);
      const options = roleChecks.map((node) => optionLabel(node)).filter(Boolean);
      for (const box of roleChecks) stamp(box, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: "",
        id: heading?.id ?? "",
        label,
        placeholder: "",
        ariaLabel: "",
        nearbyText: label,
        type: "checkbox",
        inputType: "checkbox",
        options,
        required: isMarkedRequired(item, heading, label),
        autocomplete: ""
      });
      continue;
    }
    if (roleChecks.length === 1) {
      seen.add(key);
      const only = roleChecks[0];
      const option = optionLabel(only) || label || "Confirm";
      stamp(only, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: "",
        id: heading?.id ?? "",
        label: label || option,
        placeholder: "",
        ariaLabel: attr(only, "aria-label"),
        nearbyText: `${label} ${option}`.trim(),
        type: "checkbox",
        inputType: "checkbox",
        options: [option],
        required: isMarkedRequired(item, heading, label, only),
        autocomplete: ""
      });
      continue;
    }
    const nativeChecks = Array.from(item.querySelectorAll('input[type="checkbox"]'));
    if (nativeChecks.length === 1 && !item.querySelector("input:not([type=checkbox]):not([type=hidden])")) {
      seen.add(key);
      const only = nativeChecks[0];
      const option = optionLabel(only) || label || "Confirm";
      stamp(only, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: only.name || "",
        id: only.id || heading?.id || "",
        label: label || option,
        placeholder: "",
        ariaLabel: attr(only, "aria-label"),
        nearbyText: `${label} ${option}`.trim(),
        type: "checkbox",
        inputType: "checkbox",
        options: [option],
        required: isMarkedRequired(item, heading, label, only),
        autocomplete: ""
      });
      continue;
    }
    const addFile = Array.from(item.querySelectorAll('[role="button"], button')).find(
      (node) => /add file|upload file|browse/i.test(`${attr(node, "aria-label")} ${node.textContent ?? ""}`)
    ) || (/cv or resume|upload.*(pdf|file)|attach.*(resume|cv|file)/i.test(textBlob) ? item : null);
    const fileInput = item.querySelector('input[type="file"]');
    if (addFile || fileInput || /cv or resume|resume \(pdf\)|upload.*(resume|cv|pdf)/i.test(textBlob)) {
      seen.add(key);
      if (fileInput) stamp(fileInput, key);
      if (addFile && addFile !== item) stamp(addFile, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: "",
        id: heading?.id ?? "",
        label,
        placeholder: "",
        ariaLabel: "",
        nearbyText: label,
        type: "file",
        inputType: "file",
        options: [],
        required: isMarkedRequired(item, heading, label),
        autocomplete: ""
      });
      continue;
    }
    const textControl = item.querySelector('textarea, input[type="text"], input:not([type]), [role="textbox"], [contenteditable="true"]') || null;
    if (textControl && label.trim()) {
      seen.add(key);
      const tag = textControl.tagName.toLowerCase();
      const isArea = tag === "textarea" || textControl.getAttribute("role") === "textbox" || textControl.getAttribute("contenteditable") === "true" || (textControl.textContent ?? "").length > 0 && tag === "div";
      stamp(textControl, key);
      const nested = textControl.querySelector?.("input, textarea");
      if (nested) stamp(nested, key);
      stampCard(item, key);
      pushField(fields, {
        key,
        name: attr(textControl, "name") || textControl.name || "",
        id: heading?.id ?? attr(textControl, "id"),
        label,
        placeholder: attr(textControl, "placeholder") || "Your answer",
        ariaLabel: attr(textControl, "aria-label"),
        nearbyText: `${label} ${(item.textContent ?? "").slice(0, 280)}`.trim(),
        type: isArea ? "textarea" : "text",
        inputType: isArea ? "textarea" : "text",
        options: [],
        required: isMarkedRequired(item, heading, label, textControl),
        autocomplete: attr(textControl, "autocomplete")
      });
    }
  }
  return fields;
}
function fieldKey(el, index, name, id) {
  if (name) return name;
  if (id) return id;
  const item = el.closest('[role="listitem"]');
  const heading = item?.querySelector('[role="heading"]');
  const headingId = heading?.id || attr(heading ?? el, "id");
  if (item && headingId) return `listitem:${headingId}`;
  const labelledBy = attr(el, "aria-labelledby");
  if (labelledBy) return `labelledby:${labelledBy}`;
  const ariaLabel = attr(el, "aria-label");
  if (ariaLabel) return `aria:${ariaLabel.slice(0, 48)}`;
  return `pos:${index}`;
}
function inventoryFromDocument(root2) {
  const fields = [];
  const seen = /* @__PURE__ */ new Set();
  for (const field of inventoryGoogleFormsListitems(root2, seen)) {
    fields.push(field);
  }
  const nodes = Array.from(root2.querySelectorAll("input, textarea, select"));
  for (const [index, el] of nodes.entries()) {
    const tag = el.tagName.toLowerCase();
    const inputType = (attr(el, "type") || el.type || "").toLowerCase();
    if (inputType === "hidden" || inputType === "submit" || inputType === "button" || inputType === "image" || inputType === "reset") {
      continue;
    }
    const listKey = existingListitemKey(el, root2);
    if (listKey && seen.has(listKey)) {
      stamp(el, listKey);
      continue;
    }
    const name = attr(el, "name") || el.name || "";
    const id = attr(el, "id") || el.id || "";
    const key = fieldKey(el, index, name, id);
    if (seen.has(key) && inputType !== "radio") {
      stamp(el, key);
      continue;
    }
    if (inputType === "radio") {
      const groupKey = name ? `radio:${name}` : key.startsWith("listitem:") ? `radio:${key}` : "";
      if (groupKey && seen.has(groupKey)) {
        stamp(el, key);
        continue;
      }
      if (groupKey) seen.add(groupKey);
    }
    if (seen.has(key) && inputType !== "radio") continue;
    seen.add(key);
    const label = labelFor(el, root2);
    const placeholder = attr(el, "placeholder");
    const ariaLabel = attr(el, "aria-label");
    const nearby = nearbyText(el);
    const multiple = el.hasAttribute("multiple");
    const type = normalizeType(tag, inputType, multiple);
    const options = choiceOptions(el, inputType, root2);
    const draft = {
      key,
      name,
      id,
      label,
      placeholder,
      ariaLabel,
      nearbyText: nearby,
      type,
      inputType,
      options,
      required: el.hasAttribute("required") || attr(el, "aria-required") === "true" || /required|\*/i.test(label) || (el.closest('[role="listitem"]') ? isMarkedRequired(el.closest('[role="listitem"]'), el.closest('[role="listitem"]')?.querySelector('[role="heading"]') ?? null, label, el) : false),
      autocomplete: attr(el, "autocomplete"),
      signals: ""
    };
    draft.label = humanQuestionLabel(draft);
    draft.signals = fieldSignals(draft);
    if (isNoiseFormField(draft)) continue;
    stamp(el, key);
    stampCard(el.closest('[role="listitem"]'), key);
    if ((inputType === "radio" || inputType === "checkbox") && key.startsWith("listitem:")) {
      const item = el.closest('[role="listitem"]');
      for (const sibling of Array.from(item?.querySelectorAll(`input[type="${inputType}"]`) ?? [])) {
        stamp(sibling, key);
      }
    }
    fields.push(draft);
  }
  return fields;
}

// ../../packages/form-engine/src/step-controls.ts
var CONTROL_SELECTOR = 'button, a[href], [role="button"], input[type="button"], input[type="submit"], [data-action], [data-testid], [data-qa]';
var FINAL_SUBMIT_RE = /\b(submit application|submit form|submit your application|place order|pay now|finalize|confirm payment|complete application|send application|finish application|apply now)\b/i;
var STEP_ADVANCE_RE = /\b(next|continue|proceed|weiter|siguiente|suivant|avanti|próximo|proximo|siguiente paso|save\s*(&|and)?\s*continue|save\s*(&|and)?\s*next|continue\s*to|go\s*to\s*(the\s*)?(next\s*)?(step|page)|step\s*\d+|page\s*\d+|review(\s+application)?)\b/i;
var STEP_ADVANCE_ATTR_RE = /\b(btn[-_]?next|step[-_]?next|wizard[-_]?next|continue[-_]?btn|next[-_]?step|nextButton|continueButton)\b/i;
function controlSignalText(el) {
  const control = el;
  return [
    control.textContent ?? "",
    control.getAttribute("aria-label") ?? "",
    control.getAttribute("title") ?? "",
    control.getAttribute("value") ?? "",
    control.getAttribute("name") ?? "",
    control.getAttribute("data-action") ?? "",
    control.getAttribute("data-testid") ?? "",
    control.getAttribute("data-qa") ?? "",
    control.id ?? "",
    typeof control.className === "string" ? control.className : ""
  ].join(" ").replace(/\s+/g, " ").trim();
}
function classifyActionControl(el) {
  const text = controlSignalText(el);
  if (!text) return "other";
  const hasAdvance = STEP_ADVANCE_RE.test(text) || STEP_ADVANCE_ATTR_RE.test(text);
  const hasFinal = FINAL_SUBMIT_RE.test(text);
  if (hasFinal && !hasAdvance) return "submit";
  if (hasAdvance) return "next";
  const tag = el.tagName?.toLowerCase?.() ?? "";
  const typeAttr = (typeof el.getAttribute === "function" ? el.getAttribute("type") : null) || ("type" in el ? String(el.type ?? "") : "");
  if ((tag === "button" || tag === "input") && typeAttr.toLowerCase() === "submit" && !hasAdvance) {
    if (/\bsubmit\b/i.test(text)) return "submit";
  }
  return "other";
}
function isVisibleEnabled(el) {
  if (el.disabled) return false;
  if (el.getAttribute("aria-disabled") === "true") return false;
  if (typeof window === "undefined" || typeof window.getComputedStyle !== "function") return true;
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden" || style.pointerEvents === "none") {
    return false;
  }
  const rect = el.getBoundingClientRect();
  if (rect.width < 2 || rect.height < 2) return false;
  return true;
}
function findStepAdvanceControls(root2) {
  const nodes = Array.from(root2.querySelectorAll(CONTROL_SELECTOR));
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const node of nodes) {
    const control = node.closest(CONTROL_SELECTOR) ?? node;
    if (seen.has(control)) continue;
    seen.add(control);
    if (classifyActionControl(control) !== "next") continue;
    if (!isVisibleEnabled(control)) continue;
    out.push(control);
  }
  out.sort((a, b) => {
    if (typeof a.getBoundingClientRect !== "function") return 0;
    return a.getBoundingClientRect().top - b.getBoundingClientRect().top;
  });
  return out;
}
function findPrimaryStepAdvance(root2) {
  const controls = findStepAdvanceControls(root2);
  if (!controls.length) return null;
  const preferred = controls.find(
    (el) => /\b(next|continue|save\s*(&|and)?\s*continue)\b/i.test(controlSignalText(el))
  );
  return preferred ?? controls[controls.length - 1] ?? null;
}
function isStepAdvanceControl(el) {
  if (!el) return false;
  const control = el.closest(CONTROL_SELECTOR);
  if (!control) return false;
  return classifyActionControl(control) === "next";
}

// ../../packages/form-engine/src/field-limits.ts
function parsePositiveInt(raw) {
  const n = typeof raw === "number" ? raw : Number(String(raw ?? "").replace(/,/g, ""));
  if (!Number.isFinite(n) || n <= 0 || n >= 1e5) return null;
  return Math.floor(n);
}
function detectFieldLengthLimit(el, label = "", nearby = "") {
  const input = el;
  const attrMax = input.getAttribute?.("maxlength") ?? input.getAttribute?.("maxLength");
  const maxLength = parsePositiveInt(
    typeof input.maxLength === "number" && input.maxLength > 0 ? input.maxLength : attrMax
  );
  if (maxLength && maxLength < 5e4) {
    return { value: maxLength, unit: "characters", source: "maxlength" };
  }
  const card = el.closest('[role="listitem"]') || el.closest("fieldset") || el.parentElement;
  const cardText = (card?.textContent ?? "").replace(/\s+/g, " ").trim().slice(0, 800);
  const blob = `${label} ${nearby} ${el.getAttribute("aria-description") ?? ""} ${el.getAttribute("aria-label") ?? ""} ${cardText}`;
  const wordPatterns = [
    /(?:max(?:imum)?|limit(?:ed)?\s*(?:to|of)?|up\s*to|no\s*more\s*than|not\s*more\s*than|within)\s*(\d{1,5})\s*words?\b/i,
    /\b(\d{1,5})\s*words?\s*(?:max(?:imum)?|limit|or\s*less|allowed|only)?\b/i,
    /word\s*limit\s*[:=]?\s*(\d{1,5})\b/i
  ];
  for (const pattern of wordPatterns) {
    const match = blob.match(pattern);
    const value = parsePositiveInt(match?.[1]);
    if (value) return { value, unit: "words", source: "label" };
  }
  const charPatterns = [
    /(?:max(?:imum)?|limit(?:ed)?\s*(?:to|of)?|up\s*to|no\s*more\s*than)\s*(\d{1,6})\s*(?:characters?|chars?)\b/i,
    /\b(\d{1,6})\s*(?:characters?|chars?)\s*(?:max(?:imum)?|limit|or\s*less)?\b/i,
    /character\s*limit\s*[:=]?\s*(\d{1,6})\b/i
  ];
  for (const pattern of charPatterns) {
    const match = blob.match(pattern);
    const value = parsePositiveInt(match?.[1]);
    if (value) return { value, unit: "characters", source: "label" };
  }
  const counter = cardText.match(/\b(\d{1,6})\s*\/\s*(\d{1,6})\b/);
  const counterMax = parsePositiveInt(counter?.[2]);
  if (counterMax) {
    if (/\bwords?\b/i.test(cardText.slice(Math.max(0, (counter?.index ?? 0) - 40), (counter?.index ?? 0) + 40))) {
      return { value: counterMax, unit: "words", source: "counter" };
    }
    return { value: counterMax, unit: "characters", source: "counter" };
  }
  return null;
}
function describeFieldLengthLimit(limit) {
  if (!limit) return "";
  return `Max ${limit.value} ${limit.unit}`;
}

// ../../packages/form-engine/src/autofill.ts
function assertFillActionAllowed(action) {
  if (isForbiddenFillAction(action)) {
    throw new Error("1-Apply never submits, bypasses CAPTCHA, or creates host accounts.");
  }
}

// src/content/content.ts
var WIDGET_ATTR = "data-1apply-chip";
var HIGHLIGHT_STYLE_ID = "oneapply-highlight-style";
var TOAST_ATTR = "data-1apply-toast";
var root = globalThis;
if (!root.__1APPLY_LISTENERS) {
  let clearPendingTimers = function() {
    if (root.__1APPLY_CONTINUE_TIMER) {
      window.clearTimeout(root.__1APPLY_CONTINUE_TIMER);
      root.__1APPLY_CONTINUE_TIMER = null;
    }
    for (const id of root.__1APPLY_PENDING_TIMERS ?? []) {
      window.clearTimeout(id);
    }
    root.__1APPLY_PENDING_TIMERS = [];
  }, trackTimeout = function(handler, delay) {
    const id = window.setTimeout(() => {
      root.__1APPLY_PENDING_TIMERS = (root.__1APPLY_PENDING_TIMERS ?? []).filter((item) => item !== id);
      handler();
    }, delay);
    root.__1APPLY_PENDING_TIMERS = [...root.__1APPLY_PENDING_TIMERS ?? [], id];
    return id;
  }, isFillActive = function() {
    return Boolean(root.__1APPLY_AUTO_CONTINUE) && !root.__1APPLY_STOPPED;
  }, pageFingerprint = function() {
    const urlKey = `${location.origin}${location.pathname}?${location.search}#${location.hash}`;
    const fields = inventoryFromDocument(document);
    const fieldKey2 = fields.map((field) => `${field.type}|${(field.label || field.name || field.key).slice(0, 120)}`).sort().join("\n");
    const headings = Array.from(document.querySelectorAll('h1, h2, h3, [role="heading"], legend')).slice(0, 16).map((el) => (el.textContent ?? "").trim().replace(/\s+/g, " ").slice(0, 80)).filter(Boolean).join("|");
    const visibleControls = Array.from(
      document.querySelectorAll(
        'input:not([type=hidden]), textarea, select, [role="textbox"], [role="listbox"], [role="radio"], [role="checkbox"], [contenteditable="true"]'
      )
    ).filter((el) => {
      const node = el;
      if (!node.getBoundingClientRect) return true;
      const rect = node.getBoundingClientRect();
      const style = window.getComputedStyle(node);
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    }).length;
    return [urlKey, `visible=${visibleControls}`, headings, fieldKey2].join("\n---\n");
  }, showToast = function(text) {
    document.querySelector(`[${TOAST_ATTR}]`)?.remove();
    const toast = document.createElement("div");
    toast.setAttribute(TOAST_ATTR, "1");
    toast.textContent = text;
    toast.style.cssText = "position:fixed;z-index:2147483647;right:16px;bottom:16px;max-width:280px;padding:12px 14px;border-radius:14px;background:#0e0e0e;color:#fff;font:600 12px/1.4 system-ui,sans-serif;box-shadow:0 12px 30px rgba(0,0,0,.24);";
    document.documentElement.append(toast);
    window.setTimeout(() => toast.remove(), 3200);
  }, requestAutoContinue = function(force = false) {
    if (!isFillActive() || root.__1APPLY_FILLING) return;
    const fp = pageFingerprint();
    if (!fp) return;
    if (!force && fp === root.__1APPLY_LAST_PAGE_FP) return;
    const pendingFp = fp;
    chrome.runtime.sendMessage({ type: "AUTO_CONTINUE_FILL", url: location.href, fingerprint: pendingFp }, (response) => {
      if (!isFillActive()) return;
      if (chrome.runtime.lastError) {
        root.__1APPLY_CONTINUE_TRIES = (root.__1APPLY_CONTINUE_TRIES ?? 0) + 1;
        if ((root.__1APPLY_CONTINUE_TRIES ?? 0) <= 4) {
          trackTimeout(() => requestAutoContinue(true), 700 * (root.__1APPLY_CONTINUE_TRIES ?? 1));
        }
        return;
      }
      const ok = Boolean(response && typeof response === "object" && response.ok);
      const reason = response && typeof response === "object" ? String(response.reason ?? "") : "";
      if (ok) {
        root.__1APPLY_LAST_PAGE_FP = pageFingerprint();
        root.__1APPLY_CONTINUE_TRIES = 0;
        const filled = Number(response.filled ?? 0);
        showToast(filled ? `1-Apply filled ${filled} field(s) on this step.` : "1-Apply ready on this step.");
        return;
      }
      if (reason === "no-fields" || reason === "busy" || reason.includes("bad-tab") || reason.includes("Receiving end")) {
        root.__1APPLY_CONTINUE_TRIES = (root.__1APPLY_CONTINUE_TRIES ?? 0) + 1;
        if ((root.__1APPLY_CONTINUE_TRIES ?? 0) <= 6) {
          trackTimeout(() => requestAutoContinue(true), 600 + 400 * (root.__1APPLY_CONTINUE_TRIES ?? 1));
        }
        return;
      }
      if (reason === "no-session" || reason === "origin-mismatch" || reason === "stopped") {
        root.__1APPLY_AUTO_CONTINUE = false;
        root.__1APPLY_STOPPED = true;
        clearPendingTimers();
      }
    });
  }, isStepAdvanceControlLocal = function(el) {
    return isStepAdvanceControl(el);
  }, scheduleAutoContinue = function(delay = 800, force = false) {
    if (!isFillActive() || root.__1APPLY_FILLING) return;
    if (root.__1APPLY_CONTINUE_TIMER) window.clearTimeout(root.__1APPLY_CONTINUE_TIMER);
    root.__1APPLY_CONTINUE_TIMER = window.setTimeout(() => {
      root.__1APPLY_CONTINUE_TIMER = null;
      requestAutoContinue(force);
    }, delay);
  }, enableAutoContinueWatch = function() {
    if (root.__1APPLY_STOPPED) return;
    const wasActive = root.__1APPLY_AUTO_CONTINUE;
    root.__1APPLY_AUTO_CONTINUE = true;
    if (!wasActive) root.__1APPLY_STEPS = 0;
    if (root.__1APPLY_PAGE_WATCH) return;
    root.__1APPLY_PAGE_WATCH = true;
    const observer = new MutationObserver(() => scheduleAutoContinue(1e3));
    if (document.body) {
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class", "style", "hidden", "aria-hidden", "aria-checked", "data-value"]
      });
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        observer.observe(document.body, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["class", "style", "hidden", "aria-hidden", "aria-checked", "data-value"]
        });
      });
    }
    document.addEventListener(
      "click",
      (event) => {
        if (!isFillActive()) return;
        if (isStepAdvanceControlLocal(event.target)) {
          root.__1APPLY_LAST_PAGE_FP = void 0;
          root.__1APPLY_CONTINUE_TRIES = 0;
          trackTimeout(() => requestAutoContinue(true), 1200);
          trackTimeout(() => requestAutoContinue(true), 2500);
          trackTimeout(() => requestAutoContinue(true), 4500);
        }
      },
      true
    );
    document.addEventListener(
      "submit",
      () => {
        if (!isFillActive()) return;
        root.__1APPLY_LAST_PAGE_FP = void 0;
        trackTimeout(() => requestAutoContinue(true), 1200);
        trackTimeout(() => requestAutoContinue(true), 2800);
      },
      true
    );
    window.addEventListener("popstate", () => {
      if (!isFillActive()) return;
      root.__1APPLY_LAST_PAGE_FP = void 0;
      scheduleAutoContinue(700, true);
    });
    window.addEventListener("hashchange", () => {
      if (!isFillActive()) return;
      root.__1APPLY_LAST_PAGE_FP = void 0;
      scheduleAutoContinue(700, true);
    });
    const wrapHistory = (method) => {
      const original = history[method].bind(history);
      history[method] = (...args) => {
        const result = original(...args);
        if (isFillActive()) {
          root.__1APPLY_LAST_PAGE_FP = void 0;
          scheduleAutoContinue(800, true);
        }
        return result;
      };
    };
    wrapHistory("pushState");
    wrapHistory("replaceState");
  }, disableAutoContinueWatch = function() {
    root.__1APPLY_STOPPED = true;
    root.__1APPLY_AUTO_CONTINUE = false;
    root.__1APPLY_LAST_PAGE_FP = void 0;
    root.__1APPLY_CONTINUE_TRIES = 0;
    root.__1APPLY_STEPS = 0;
    root.__1APPLY_ADVANCE_LOCK = false;
    clearPendingTimers();
  }, cssEscape2 = function(value) {
    if (typeof CSS !== "undefined" && CSS.escape) return CSS.escape(value);
    return value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }, sleep = function(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }, findTagged = function(fieldKey2) {
    return document.querySelector(`[${APPLY_FIELD_ATTR}="${cssEscape2(fieldKey2)}"]`);
  }, findCard = function(fieldKey2) {
    const tagged = findTagged(fieldKey2);
    if (!tagged) return null;
    return tagged.closest(`[${APPLY_HOST_ATTR}]`) || tagged.closest('[role="listitem"]') || tagged;
  }, findControl = function(fieldKey2) {
    const tagged = findTagged(fieldKey2);
    if (tagged) return tagged;
    return document.querySelector(`[name="${cssEscape2(fieldKey2)}"]`) || document.querySelector(`#${cssEscape2(fieldKey2)}`);
  }, readControlValue = function(fieldKey2, fieldType) {
    const el = findControl(fieldKey2);
    if (!el) return "";
    if (fieldType === "radio" || el instanceof HTMLInputElement && el.type === "radio") {
      const radios = Array.from(
        document.querySelectorAll(`input[type="radio"][${APPLY_FIELD_ATTR}="${cssEscape2(fieldKey2)}"]`)
      );
      const checked = radios.find((item) => item.checked) ?? (el instanceof HTMLInputElement && el.checked ? el : null);
      if (!checked) return "";
      return (checked.value || checked.getAttribute("aria-label") || checked.labels?.[0]?.textContent || "").trim().replace(/\s+/g, " ");
    }
    if (fieldType === "checkbox" || el instanceof HTMLInputElement && el.type === "checkbox") {
      const boxes = Array.from(
        document.querySelectorAll(`input[type="checkbox"][${APPLY_FIELD_ATTR}="${cssEscape2(fieldKey2)}"]`)
      );
      const checked = (boxes.length ? boxes : el instanceof HTMLInputElement ? [el] : []).filter((item) => item.checked);
      return checked.map((item) => item.value && item.value !== "on" ? item.value : item.labels?.[0]?.textContent || "true").map((value) => value.trim().replace(/\s+/g, " ")).filter(Boolean).join(", ");
    }
    if (el instanceof HTMLSelectElement) {
      return Array.from(el.selectedOptions).map((option) => option.textContent?.trim() || option.value).filter(Boolean).join(", ");
    }
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      if (el instanceof HTMLInputElement && el.type === "file") {
        return Array.from(el.files ?? []).map((file) => file.name).join(", ");
      }
      return el.value.trim();
    }
    if (el.isContentEditable || el.getAttribute("role") === "textbox") {
      return (el.textContent ?? "").trim().replace(/\s+/g, " ");
    }
    const listbox = el.getAttribute("role") === "listbox" ? el : el.querySelector('[role="option"][aria-selected="true"]');
    if (listbox) {
      const selected = el.querySelectorAll('[role="option"][aria-selected="true"]');
      if (selected.length) {
        return Array.from(selected).map((node) => (node.textContent ?? "").trim().replace(/\s+/g, " ")).filter(Boolean).join(", ");
      }
    }
    return "";
  }, optionText = function(node) {
    return (node.getAttribute("aria-label") || node.getAttribute("data-value") || node.querySelector("span")?.textContent || node.textContent || "").trim().replace(/\s+/g, " ");
  }, setNativeTextValue = function(el, value) {
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    descriptor?.set?.call(el, value);
    if (el.value !== value) el.value = value;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, inputType: "insertFromPaste", data: value }));
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    el.blur();
  }, base64ToFile = function(file) {
    const binary = atob(file.base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return new File([bytes], file.filename || "document.pdf", {
      type: file.mimeType || "application/pdf",
      lastModified: Date.now()
    });
  }, normalizeFilename = function(name) {
    return name.trim().toLowerCase().replace(/^.*[\\/]/, "");
  }, filenamesMatch = function(a, b) {
    const left = normalizeFilename(a);
    const right = normalizeFilename(b);
    if (!left || !right) return false;
    if (left === right) return true;
    const stem = (value) => value.replace(/\.[a-z0-9]{1,8}$/i, "");
    const leftStem = stem(left);
    const rightStem = stem(right);
    return Boolean(leftStem.length >= 4 && leftStem === rightStem);
  }, fileAlreadyUploaded = function(scope, filename) {
    const wanted = filename ? normalizeFilename(filename) : "";
    const inputs = Array.from(scope.querySelectorAll('input[type="file"]'));
    for (const input of inputs) {
      const files = Array.from(input.files ?? []);
      if (!files.length) continue;
      if (!wanted) return true;
      if (files.some((item) => filenamesMatch(item.name, wanted))) return true;
    }
    const blob = (scope.textContent ?? "").replace(/\s+/g, " ");
    if (wanted && blob.toLowerCase().includes(wanted)) {
      if (/uploaded|selected|attached|remove file|replace file|\.pdf|\.docx?/i.test(blob)) return true;
    }
    if (wanted) {
      const named = Array.from(scope.querySelectorAll("a, span, div, li, [role='listitem'], [data-tooltip]")).some((node) => {
        const text = (node.textContent ?? node.getAttribute("data-tooltip") ?? "").trim();
        return filenamesMatch(text, wanted) || normalizeFilename(text).endsWith(wanted);
      });
      if (named && /remove|uploaded|file|pdf|docx?/i.test(blob)) return true;
    }
    return false;
  }, applyFile = function(el, file) {
    if (fileAlreadyUploaded(el.form ?? el.parentElement ?? document, file.filename) || fileAlreadyUploaded(el, file.filename)) {
      return true;
    }
    if (!file.base64) return false;
    const transfer = new DataTransfer();
    transfer.items.add(base64ToFile(file));
    el.files = transfer.files;
    el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    return (el.files?.length ?? 0) > 0;
  }, isTruthyCheckValue = function(value) {
    return /^(true|yes|1|checked|on|confirm)$/i.test(value.trim());
  }, activateToggle = function(el) {
    el.focus?.();
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window, buttons: 1 }));
    }
    el.click();
    el.dispatchEvent(new KeyboardEvent("keydown", { key: " ", code: "Space", keyCode: 32, which: 32, bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { key: " ", code: "Space", keyCode: 32, which: 32, bubbles: true }));
  }, isToggleChecked = function(el) {
    if (el instanceof HTMLInputElement) return el.checked;
    return el.getAttribute("aria-checked") === "true";
  }, isControlFilled = function(fieldKey2, el) {
    const card = findCard(fieldKey2) || el;
    if (card.querySelector('[role="listbox"]')) {
      const listbox = card.querySelector('[role="listbox"]');
      const text2 = (listbox?.textContent ?? "").trim().toLowerCase();
      return Boolean(text2 && text2 !== "choose" && !text2.includes("choose"));
    }
    if (card.querySelector('[role="radio"]')) {
      return Array.from(card.querySelectorAll('[role="radio"]')).some((node) => node.getAttribute("aria-checked") === "true");
    }
    if (card.querySelector('[role="checkbox"]')) {
      return Array.from(card.querySelectorAll('[role="checkbox"]')).some((node) => node.getAttribute("aria-checked") === "true");
    }
    const file = card.querySelector('input[type="file"]');
    if (file) return (file.files?.length ?? 0) > 0 || fileAlreadyUploaded(card);
    if (el instanceof HTMLInputElement && el.type === "file") {
      return (el.files?.length ?? 0) > 0 || fileAlreadyUploaded(card) || fileAlreadyUploaded(el);
    }
    if (/add file|upload|resume|cv|attach/i.test(card.textContent ?? "") && fileAlreadyUploaded(card)) return true;
    if (/add file/i.test(card.textContent ?? "") && /uploaded|selected file|\.pdf/i.test(card.textContent ?? "")) return true;
    if (el instanceof HTMLSelectElement) return Boolean(el.value);
    if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox")) {
      return Array.from(document.querySelectorAll(`input[type="${el.type}"][${APPLY_FIELD_ATTR}="${cssEscape2(fieldKey2)}"]`)).some(
        (node) => node.checked
      );
    }
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return Boolean(el.value?.trim());
    const text = card.querySelector("input:not([type=hidden]):not([type=file]), textarea");
    return Boolean(text?.value?.trim());
  }, ensureHighlightStyle = function() {
    if (document.getElementById(HIGHLIGHT_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = HIGHLIGHT_STYLE_ID;
    style.textContent = `
      [${APPLY_EMPTY_ATTR}="1"] {
        outline: 2px solid #c45c26 !important;
        outline-offset: 3px !important;
        box-shadow: 0 0 0 4px rgba(196, 92, 38, 0.16) !important;
        border-radius: 8px;
      }
    `;
    document.documentElement.append(style);
  }, clearHighlights = function() {
    for (const node of Array.from(document.querySelectorAll(`[${APPLY_EMPTY_ATTR}]`))) {
      node.removeAttribute(APPLY_EMPTY_ATTR);
    }
  }, highlightEmpty = function(fieldKeys) {
    ensureHighlightStyle();
    clearHighlights();
    const keys = fieldKeys.length ? fieldKeys : Array.from(document.querySelectorAll(`[${APPLY_FIELD_ATTR}]`)).map((node) => node.getAttribute(APPLY_FIELD_ATTR) || "");
    const seen = /* @__PURE__ */ new Set();
    for (const key of keys) {
      if (!key || seen.has(key)) continue;
      seen.add(key);
      const el = findControl(key);
      if (!el) continue;
      if (isControlFilled(key, el)) continue;
      const card = findCard(key) || el;
      card.setAttribute(APPLY_EMPTY_ATTR, "1");
    }
  }, clearChips = function() {
    for (const node of Array.from(document.querySelectorAll(`[${WIDGET_ATTR}]`))) node.remove();
  }, ensureMenuCloser = function() {
    if (menuCloserBound) return;
    menuCloserBound = true;
    document.addEventListener(
      "click",
      (event) => {
        const path = typeof event.composedPath === "function" ? event.composedPath() : [];
        if (path.some((node) => node instanceof Element && node.hasAttribute(WIDGET_ATTR))) return;
        closeAllAssistants();
      },
      true
    );
  }, uniqueOptions = function(options, primary) {
    const list = options?.length ? options : primary ? [{ value: primary }] : [];
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const option of list) {
      const value = option.value?.trim();
      if (!value || seen.has(value)) continue;
      seen.add(value);
      out.push({ ...option, value });
    }
    if (primary.trim() && !seen.has(primary.trim())) out.unshift({ value: primary.trim() });
    return out;
  }, closeAllAssistants = function(except) {
    for (const host of Array.from(document.querySelectorAll(`[${WIDGET_ATTR}]`))) {
      if (except && host === except) continue;
      host.shadowRoot?.querySelector(".panel")?.classList.remove("open");
      host.shadowRoot?.querySelector(".menu")?.classList.remove("open");
    }
  }, mountAiAssistant = function(anchor, fieldKey2, question, fieldType, applicationId, memoryOptions) {
    const card = findCard(fieldKey2) || anchor;
    card.querySelector(`[${WIDGET_ATTR}]`)?.remove();
    if (getComputedStyle(card).position === "static") card.style.position = "relative";
    const host = document.createElement("div");
    host.setAttribute(WIDGET_ATTR, "ai");
    host.style.cssText = "position:absolute;top:8px;right:8px;z-index:2147483646;font:12px/1.4 'Segoe UI',system-ui,sans-serif;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        @keyframes pop { from { transform: translateY(4px) scale(.96); opacity: 0; } to { transform: none; opacity: 1; } }
        @keyframes pulse { 0%,100% { opacity: .55; } 50% { opacity: 1; } }
        .fab {
          width: 34px; height: 34px; border-radius: 12px; border: 1px solid #0e0e0e;
          background: linear-gradient(145deg, #e8f6ef, #d8efe4); color: #0e0e0e;
          font: 700 11px/1 ui-monospace, monospace; letter-spacing: .04em;
          cursor: pointer; box-shadow: 0 8px 22px rgba(14,14,14,.16);
          animation: pop .28s ease-out;
        }
        .fab:hover { background: #0e0e0e; color: #fff; }
        .panel {
          display: none; position: absolute; top: 42px; right: 0; width: min(360px, 86vw);
          background: #fbfbf7; border: 1px solid #e4e4dc; border-radius: 16px;
          box-shadow: 0 18px 40px rgba(14,14,14,.18); overflow: hidden; animation: pop .22s ease-out;
        }
        .panel.open { display: grid; }
        .head {
          display: flex; align-items: start; justify-content: space-between; gap: 10px;
          padding: 12px 14px 8px; border-bottom: 1px solid #ecece4;
        }
        .eyebrow { margin: 0; font: 10px/1.2 ui-monospace, monospace; letter-spacing: .14em; text-transform: uppercase; color: #6b6b63; }
        .title { margin: 4px 0 0; font: 600 14px/1.3 Georgia, 'Times New Roman', serif; color: #0e0e0e; }
        .close { all: unset; cursor: pointer; color: #6b6b63; font-size: 18px; line-height: 1; padding: 2px 4px; }
        .body { padding: 12px 14px; display: grid; gap: 10px; }
        .hint { margin: 0; color: #6b6b63; font: 12px/1.45 system-ui, sans-serif; }
        .limit {
          margin: 0; display: none; padding: 6px 10px; border-radius: 999px; width: fit-content;
          background: #e8f6ef; color: #0e0e0e; font: 600 11px/1.3 ui-monospace, monospace;
        }
        .limit.show { display: inline-block; }
        .guidance-label { margin: 0; color: #6b6b63; font: 11px/1.3 system-ui, sans-serif; }
        .guidance {
          width: 100%; min-height: 56px; max-height: 100px; resize: vertical; box-sizing: border-box;
          padding: 8px 10px; border-radius: 10px; border: 1px solid #e7e7e0; background: #fff;
          color: #0e0e0e; font: 12px/1.45 system-ui, sans-serif;
        }
        .guidance:focus { outline: 2px solid #0e0e0e; outline-offset: 1px; }
        .draft {
          display: none; max-height: 220px; overflow: auto; padding: 12px;
          border-radius: 12px; background: #fff; border: 1px solid #e7e7e0;
          white-space: pre-wrap; color: #0e0e0e; font: 13px/1.55 Georgia, 'Times New Roman', serif;
        }
        .draft.show { display: block; }
        .status { min-height: 1.2em; margin: 0; color: #6b6b63; font: 11px/1.4 ui-monospace, monospace; }
        .status.busy { animation: pulse 1.1s ease-in-out infinite; }
        .status.err { color: #7a2e24; }
        .actions { display: flex; flex-wrap: wrap; gap: 8px; }
        .btn {
          border: 1px solid #0e0e0e; border-radius: 999px; padding: 8px 14px;
          font: 600 12px/1 system-ui, sans-serif; cursor: pointer; background: #0e0e0e; color: #fff;
        }
        .btn.secondary { background: transparent; color: #0e0e0e; }
        .btn:disabled { opacity: .45; cursor: default; }
        .mem { display: none; gap: 4px; }
        .mem.show { display: grid; }
        .mem button {
          all: unset; cursor: pointer; padding: 8px 10px; border-radius: 10px; background: #fff;
          border: 1px solid #ecece4; font: 12px/1.4 system-ui, sans-serif; color: #0e0e0e;
        }
        .mem button:hover { background: #f3f4ef; }
        .mem .meta { display: block; margin-top: 2px; font: 10px/1.3 ui-monospace, monospace; color: #6b6b63; }
      </style>
      <button class="fab" type="button" title="1-Apply AI assistant" aria-label="Open 1-Apply AI assistant">1A</button>
      <div class="panel" role="dialog" aria-label="1-Apply AI draft">
        <div class="head">
          <div>
            <p class="eyebrow">1-Apply</p>
            <p class="title">Draft from memory</p>
          </div>
          <button class="close" type="button" aria-label="Close">\xD7</button>
        </div>
        <div class="body">
          <p class="hint">Generate from Application Memory. Optional notes below are included in the draft.</p>
          <p class="limit"></p>
          <label class="guidance-label">Add to this draft (optional)</label>
          <textarea class="guidance" placeholder="e.g. also mention my 3 years of freelancing" aria-label="Add guidance for this draft"></textarea>
          <div class="draft" aria-live="polite"></div>
          <p class="status"></p>
          <div class="actions">
            <button class="btn generate" type="button">Generate</button>
            <button class="btn secondary confirm" type="button" disabled>Confirm</button>
            <button class="btn secondary regenerate" type="button" disabled>Regenerate</button>
          </div>
          <div class="mem"></div>
        </div>
      </div>
    `;
    const fab = shadow.querySelector(".fab");
    const panel = shadow.querySelector(".panel");
    const draftEl = shadow.querySelector(".draft");
    const statusEl = shadow.querySelector(".status");
    const limitEl = shadow.querySelector(".limit");
    const guidanceEl = shadow.querySelector(".guidance");
    const generateBtn = shadow.querySelector(".generate");
    const confirmBtn = shadow.querySelector(".confirm");
    const regenerateBtn = shadow.querySelector(".regenerate");
    const closeBtn = shadow.querySelector(".close");
    const memEl = shadow.querySelector(".mem");
    let draftText = "";
    const lengthLimit = detectFieldLengthLimit(
      anchor,
      question,
      `${card.textContent ?? ""}`.slice(0, 600)
    );
    if (lengthLimit) {
      limitEl.textContent = describeFieldLengthLimit(lengthLimit);
      limitEl.classList.add("show");
    }
    guidanceEl.addEventListener("click", (event) => event.stopPropagation());
    guidanceEl.addEventListener("keydown", (event) => event.stopPropagation());
    if (memoryOptions.length) {
      memEl.classList.add("show");
      const label = document.createElement("p");
      label.className = "hint";
      label.textContent = "Or insert a saved memory answer:";
      memEl.append(label);
      for (const option of memoryOptions.slice(0, 4)) {
        const button = document.createElement("button");
        button.type = "button";
        button.innerHTML = `<span></span><span class="meta"></span>`;
        button.querySelector("span").textContent = option.value.length > 180 ? `${option.value.slice(0, 180)}\u2026` : option.value;
        button.querySelector(".meta").textContent = option.source || option.label || "Application Memory";
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          draftText = option.value;
          draftEl.textContent = draftText;
          draftEl.classList.add("show");
          confirmBtn.disabled = false;
          regenerateBtn.disabled = false;
          statusEl.textContent = "Loaded from Application Memory \u2014 Confirm to fill the form.";
          statusEl.className = "status";
        });
        memEl.append(button);
      }
    }
    async function runGenerate() {
      if (!applicationId) {
        statusEl.textContent = "No application selected. Save this page in 1-Apply first.";
        statusEl.className = "status err";
        return;
      }
      generateBtn.disabled = true;
      regenerateBtn.disabled = true;
      confirmBtn.disabled = true;
      const guidance = guidanceEl.value.trim();
      statusEl.textContent = lengthLimit ? `Reading Application Memory\u2026 targeting ${describeFieldLengthLimit(lengthLimit).toLowerCase()}.` : "Reading Application Memory\u2026";
      statusEl.className = "status busy";
      try {
        const result = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            {
              type: "GENERATE_AI_DRAFT",
              applicationId,
              question,
              fieldKey: fieldKey2,
              guidance: guidance || void 0,
              limitValue: lengthLimit?.value ?? null,
              limitUnit: lengthLimit?.unit ?? null
            },
            (response) => {
              const err = chrome.runtime.lastError;
              if (err) reject(new Error(err.message));
              else if (response && typeof response === "object" && "error" in response && response.error)
                reject(new Error(response.error));
              else resolve(response);
            }
          );
        });
        draftText = result.draft;
        draftEl.textContent = draftText;
        draftEl.classList.add("show");
        confirmBtn.disabled = !draftText;
        regenerateBtn.disabled = false;
        const bits = [
          result.grounded ? "Draft ready" : "Draft ready (memory looked thin \u2014 review carefully)",
          lengthLimit ? describeFieldLengthLimit(lengthLimit) : null,
          result.limitApplied ? "trimmed to fit" : null,
          "Confirm to fill"
        ].filter(Boolean);
        statusEl.textContent = `${bits.join(" \xB7 ")}.`;
        statusEl.className = "status";
      } catch (error) {
        statusEl.textContent = error instanceof Error ? error.message : "Could not generate draft.";
        statusEl.className = "status err";
        regenerateBtn.disabled = false;
      } finally {
        generateBtn.disabled = false;
      }
    }
    fab.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const open = !panel.classList.contains("open");
      closeAllAssistants(host);
      panel.classList.toggle("open", open);
    });
    closeBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      panel.classList.remove("open");
    });
    generateBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void runGenerate();
    });
    regenerateBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void runGenerate();
    });
    confirmBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!draftText.trim()) return;
      void (async () => {
        const ok = await applyValue(anchor, { fieldKey: fieldKey2, value: draftText, type: fieldType });
        if (ok) {
          card.removeAttribute(APPLY_EMPTY_ATTR);
          statusEl.textContent = "Filled into the form.";
          statusEl.className = "status";
          panel.classList.remove("open");
        } else {
          statusEl.textContent = "Could not fill this field \u2014 try clicking the input first.";
          statusEl.className = "status err";
        }
      })();
    });
    panel.addEventListener("click", (event) => event.stopPropagation());
    ensureMenuCloser();
    card.append(host);
  }, mountChip = function(anchor, fieldKey2, options, fieldType) {
    if (!options.length) return;
    const card = findCard(fieldKey2) || anchor;
    card.querySelector(`[${WIDGET_ATTR}]`)?.remove();
    if (getComputedStyle(card).position === "static") card.style.position = "relative";
    const host = document.createElement("div");
    host.setAttribute(WIDGET_ATTR, "1");
    host.style.cssText = "position:absolute;top:10px;right:10px;z-index:2147483646;font:12px/1 system-ui,sans-serif;animation:oneapply-pop .28s ease-out;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        @keyframes pop { from { transform: scale(.7); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .chip {
          min-width: 26px; height: 26px; padding: 0 8px; border-radius: 999px;
          border: 1px solid #0e0e0e; background: #d8efe4; color: #0e0e0e;
          display: inline-grid; place-items: center; cursor: pointer; gap: 4px;
          box-shadow: 0 4px 14px rgba(0,0,0,.14);
          font: 700 11px/1 system-ui, sans-serif;
          animation: pop .28s ease-out;
        }
        .chip:hover { background: #0e0e0e; color: #fff; }
        .menu {
          display: none; position: absolute; top: 32px; right: 0;
          min-width: 260px; max-width: 380px; max-height: 300px; overflow: auto;
          background: #fff; border: 1px solid #e7e7e0; border-radius: 14px;
          box-shadow: 0 12px 30px rgba(0,0,0,.16); padding: 6px;
        }
        .menu.open { display: grid; gap: 4px; }
        button.opt {
          all: unset; cursor: pointer; display: grid; gap: 2px;
          padding: 10px 12px; border-radius: 10px; color: #0e0e0e;
        }
        button.opt:hover { background: #f3f4ef; }
        .val { font: 12px/1.4 system-ui, sans-serif; white-space: pre-wrap; }
        .meta { font: 10px/1.3 ui-monospace, monospace; color: #6b6b63; }
      </style>
      <button class="chip" type="button" title="1-Apply suggestions" aria-label="Show 1-Apply suggestions">1A \xB7 ${options.length}</button>
      <div class="menu" role="listbox"></div>
    `;
    const chip = shadow.querySelector(".chip");
    const menu = shadow.querySelector(".menu");
    for (const option of options) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "opt";
      button.innerHTML = `<span class="val"></span><span class="meta"></span>`;
      button.querySelector(".val").textContent = option.label && fieldType === "file" ? option.label : option.value;
      button.querySelector(".meta").textContent = [option.label && fieldType !== "file" ? option.label : "", option.source].filter(Boolean).join(" \xB7 ") || "Application Memory";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        void (async () => {
          await applyValue(anchor, {
            fieldKey: fieldKey2,
            value: option.value,
            type: fieldType,
            file: fieldType === "file" ? { versionId: option.value, filename: option.label || "document.pdf", mimeType: "application/pdf", base64: "" } : null
          });
          card.removeAttribute(APPLY_EMPTY_ATTR);
          menu.classList.remove("open");
        })();
      });
      menu.append(button);
    }
    chip.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const open = menu.classList.toggle("open");
      if (open) closeAllAssistants(host);
    });
    ensureMenuCloser();
    card.append(host);
  };
  clearPendingTimers2 = clearPendingTimers, trackTimeout2 = trackTimeout, isFillActive2 = isFillActive, pageFingerprint2 = pageFingerprint, showToast2 = showToast, requestAutoContinue2 = requestAutoContinue, isStepAdvanceControlLocal2 = isStepAdvanceControlLocal, scheduleAutoContinue2 = scheduleAutoContinue, enableAutoContinueWatch2 = enableAutoContinueWatch, disableAutoContinueWatch2 = disableAutoContinueWatch, cssEscape3 = cssEscape2, sleep2 = sleep, findTagged2 = findTagged, findCard2 = findCard, findControl2 = findControl, readControlValue2 = readControlValue, optionText2 = optionText, setNativeTextValue2 = setNativeTextValue, base64ToFile2 = base64ToFile, normalizeFilename2 = normalizeFilename, filenamesMatch2 = filenamesMatch, fileAlreadyUploaded2 = fileAlreadyUploaded, applyFile2 = applyFile, isTruthyCheckValue2 = isTruthyCheckValue, activateToggle2 = activateToggle, isToggleChecked2 = isToggleChecked, isControlFilled2 = isControlFilled, ensureHighlightStyle2 = ensureHighlightStyle, clearHighlights2 = clearHighlights, highlightEmpty2 = highlightEmpty, clearChips2 = clearChips, ensureMenuCloser2 = ensureMenuCloser, uniqueOptions2 = uniqueOptions, closeAllAssistants2 = closeAllAssistants, mountAiAssistant2 = mountAiAssistant, mountChip2 = mountChip;
  root.__1APPLY_LISTENERS = true;
  root.__1APPLY_CONTINUE_TIMER = null;
  root.__1APPLY_CONTINUE_TRIES = 0;
  root.__1APPLY_PENDING_TIMERS = [];
  root.__1APPLY_STOPPED = false;
  async function tryAutoAdvance() {
    if (!isFillActive()) return { clicked: false, reason: "stopped" };
    if (root.__1APPLY_FILLING) return { clicked: false, reason: "busy" };
    if (root.__1APPLY_ADVANCE_LOCK) return { clicked: false, reason: "locked" };
    const steps = root.__1APPLY_STEPS ?? 0;
    if (steps >= 12) {
      showToast("1-Apply stopped after 12 pages \u2014 review and Stop when done.");
      return { clicked: false, reason: "max-steps" };
    }
    const btn = findPrimaryStepAdvance(document);
    if (!btn) {
      showToast("1-Apply finished fillable pages. Missing answers stay in Need You \u2014 Stop when done.");
      return { clicked: false, reason: "no-next" };
    }
    root.__1APPLY_ADVANCE_LOCK = true;
    try {
      if (!isFillActive()) return { clicked: false, reason: "stopped" };
      assertFillActionAllowed("clickNext");
      const before = pageFingerprint();
      root.__1APPLY_LAST_PAGE_FP = void 0;
      root.__1APPLY_CONTINUE_TRIES = 0;
      root.__1APPLY_STEPS = steps + 1;
      btn.scrollIntoView({ block: "center", inline: "nearest" });
      await sleep(80);
      if (!isFillActive()) return { clicked: false, reason: "stopped" };
      btn.click();
      showToast("1-Apply opened the next page\u2026");
      await sleep(1400);
      if (!isFillActive()) return { clicked: false, reason: "stopped" };
      const after = pageFingerprint();
      if (after && before && after === before) {
        root.__1APPLY_LAST_PAGE_FP = after;
        showToast("Next page blocked \u2014 fill highlighted fields or answer in Need You.");
        return { clicked: true, reason: "no-change" };
      }
      trackTimeout(() => requestAutoContinue(true), 400);
      trackTimeout(() => requestAutoContinue(true), 1600);
      trackTimeout(() => requestAutoContinue(true), 3200);
      return { clicked: true };
    } finally {
      root.__1APPLY_ADVANCE_LOCK = false;
    }
  }
  void chrome.storage.local.get(["fillSession"]).then((data) => {
    const session = data.fillSession;
    if (!session?.enabled || session.origin !== location.origin) return;
    if (root.__1APPLY_STOPPED) return;
    enableAutoContinueWatch();
    scheduleAutoContinue(900, true);
  });
  async function resolveFile(mapping) {
    if (mapping.file?.base64) return mapping.file;
    const versionId = mapping.file?.versionId || mapping.value;
    if (!versionId) return null;
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "FETCH_DOCUMENT", versionId }, (response) => {
        const payload = response;
        if (chrome.runtime.lastError || !payload || payload.error || !payload.base64) {
          resolve(null);
          return;
        }
        resolve({
          versionId: String(payload.versionId ?? versionId),
          filename: String(payload.filename ?? "document.pdf"),
          mimeType: String(payload.mimeType ?? "application/pdf"),
          base64: String(payload.base64)
        });
      });
    });
  }
  async function applyListbox(card, value) {
    const listbox = (card.matches('[role="listbox"]') ? card : null) || card.querySelector('[role="listbox"]') || findTagged(card.getAttribute(APPLY_FIELD_ATTR) || "");
    if (!listbox) return false;
    listbox.click();
    await sleep(250);
    const options = Array.from(document.querySelectorAll('[role="option"]'));
    const target = value.trim().toLowerCase();
    const match = options.find((option) => optionText(option).toLowerCase() === target) || options.find((option) => {
      const text = optionText(option).toLowerCase();
      return text.includes(target) || target.includes(text);
    }) || options.find((option) => {
      const text = optionText(option).toLowerCase();
      if (target.includes("delhi") && text.includes("delhi")) return true;
      const tTokens = target.split(/[^a-z0-9]+/).filter((t) => t.length > 2);
      return tTokens.some((token) => text.includes(token));
    });
    if (!match) {
      listbox.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      return false;
    }
    match.click();
    await sleep(100);
    return true;
  }
  async function applyRoleRadios(card, value) {
    const radios = Array.from(card.querySelectorAll('[role="radio"]'));
    const target = value.trim().toLowerCase();
    const compact = target.replace(/\s+/g, "");
    const match = radios.find((radio) => optionText(radio).toLowerCase() === target) || radios.find((radio) => {
      const text = optionText(radio).toLowerCase();
      return text === compact || text.includes(target) || target.includes(text);
    }) || radios.find((radio) => {
      const text = optionText(radio).toLowerCase().replace(/\s+/g, "");
      return text.length >= 2 && (compact.startsWith(text) || text.startsWith(compact.replace(/year$/, "")));
    });
    if (!match) return false;
    match.click();
    return true;
  }
  async function applyRoleChecks(card, value) {
    let boxes = Array.from(card.querySelectorAll('[role="checkbox"]'));
    if (!boxes.length) {
      boxes = Array.from(document.querySelectorAll('[role="checkbox"]')).filter((node) => {
        const text = `${node.getAttribute("aria-label") ?? ""} ${node.textContent ?? ""}`;
        return /record\s+.+\s+as the email|privacy policy|i agree|i accept/i.test(text) || card.contains(node);
      });
    }
    const wanted = value.split(/\n|;/).map((part) => part.trim().toLowerCase()).filter(Boolean);
    const soleConfirm = boxes.length === 1 && (isTruthyCheckValue(value) || wanted.length > 0);
    let changed = false;
    for (const box of boxes) {
      const label = optionText(box).toLowerCase();
      const should = soleConfirm || wanted.some((item) => label === item || label.includes(item) || item.includes(label)) || /record\s+.+\s+as the email to be included/i.test(label);
      if (should === isToggleChecked(box)) continue;
      const targets = [box, box.parentElement, box.closest('[role="listitem"]')?.querySelector('[role="checkbox"]')].filter(
        (node) => Boolean(node)
      );
      for (const target of targets) {
        activateToggle(target);
        await sleep(40);
        if (isToggleChecked(box) || isToggleChecked(target)) {
          changed = true;
          break;
        }
      }
      if (!isToggleChecked(box)) {
        activateToggle(box);
        changed = true;
      }
    }
    await sleep(80);
    return changed || boxes.some((box) => isToggleChecked(box));
  }
  async function applyGoogleFile(card, file) {
    if (fileAlreadyUploaded(card, file.filename) || fileAlreadyUploaded(document, file.filename)) {
      return true;
    }
    const existing = card.querySelector('input[type="file"]') || document.querySelector('input[type="file"]');
    if (existing && applyFile(existing, file)) return true;
    const addBtn = Array.from(card.querySelectorAll('[role="button"], button')).find(
      (node) => /add file|upload file|browse/i.test(`${node.getAttribute("aria-label") ?? ""} ${node.textContent ?? ""}`)
    );
    if (addBtn) {
      addBtn.click();
      await sleep(600);
    }
    for (let attempt = 0; attempt < 8; attempt += 1) {
      if (fileAlreadyUploaded(card, file.filename) || fileAlreadyUploaded(document, file.filename)) return true;
      const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
      for (const input of inputs) {
        if (applyFile(input, file)) return true;
      }
      const ok = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: "ATTACH_FILE_ALL_FRAMES", file }, (response) => {
          resolve(Boolean(response && response.ok));
        });
      });
      if (ok) return true;
      await sleep(350);
    }
    return false;
  }
  async function applyValue(el, mapping) {
    const card = findCard(mapping.fieldKey) || el;
    if (mapping.type === "file") {
      const cardScope = findCard(mapping.fieldKey) || el;
      const knownName = mapping.file?.filename || mapping.options?.[0]?.label || "";
      if (fileAlreadyUploaded(cardScope, knownName) || fileAlreadyUploaded(document, knownName)) {
        return true;
      }
      const file = await resolveFile(mapping);
      if (!file) return false;
      if (fileAlreadyUploaded(cardScope, file.filename) || fileAlreadyUploaded(document, file.filename)) {
        return true;
      }
      if (el instanceof HTMLInputElement && el.type === "file") return applyFile(el, file);
      return applyGoogleFile(card, file);
    }
    if (mapping.type === "select" || mapping.type === "multi-select") {
      if (el instanceof HTMLSelectElement) {
        const match = Array.from(el.options).find((option) => option.value === mapping.value) || Array.from(el.options).find((option) => option.textContent?.trim() === mapping.value) || Array.from(el.options).find((option) => (option.textContent ?? "").toLowerCase().includes(mapping.value.toLowerCase()));
        if (!match) return false;
        el.value = match.value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
      return applyListbox(card, mapping.value);
    }
    if (mapping.type === "radio") {
      if (card.querySelector('[role="radio"]')) return applyRoleRadios(card, mapping.value);
      const nodes = Array.from(
        document.querySelectorAll(`input[type="radio"][${APPLY_FIELD_ATTR}="${cssEscape2(mapping.fieldKey)}"]`)
      );
      const target = mapping.value.trim().toLowerCase();
      for (const node of nodes) {
        const label = `${node.getAttribute("aria-label") ?? ""} ${node.labels?.[0]?.textContent ?? ""} ${node.value}`.toLowerCase();
        if (label.includes(target) || target.includes(node.value.toLowerCase())) {
          if (!node.checked) node.click();
          return true;
        }
      }
      return false;
    }
    if (mapping.type === "checkbox") {
      if (card.querySelector('[role="checkbox"]')) return applyRoleChecks(card, mapping.value);
      const nodes = Array.from(
        document.querySelectorAll(`input[type="checkbox"][${APPLY_FIELD_ATTR}="${cssEscape2(mapping.fieldKey)}"]`)
      );
      const wanted = mapping.value.split(/\n|;/).map((part) => part.trim().toLowerCase()).filter(Boolean);
      const soleConfirm = nodes.length === 1 && (isTruthyCheckValue(mapping.value) || wanted.length > 0);
      let changed = false;
      for (const node of nodes) {
        const label = `${node.getAttribute("aria-label") ?? ""} ${node.labels?.[0]?.textContent ?? ""} ${node.value}`.toLowerCase();
        const should = soleConfirm || wanted.some((item) => label.includes(item) || item.includes(node.value.toLowerCase()));
        if (node.checked !== should) {
          node.click();
          changed = true;
        }
      }
      return changed || nodes.some((node) => node.checked);
    }
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      setNativeTextValue(el, mapping.value);
      return true;
    }
    const textInput = card.querySelector(
      "input:not([type=hidden]):not([type=file]):not([type=radio]):not([type=checkbox]), textarea"
    );
    if (textInput) {
      setNativeTextValue(textInput, mapping.value);
      return true;
    }
    const editable = (el.getAttribute("contenteditable") === "true" || el.getAttribute("role") === "textbox" ? el : null) || card.querySelector('[contenteditable="true"], [role="textbox"]');
    if (editable) {
      editable.focus();
      editable.textContent = mapping.value;
      editable.dispatchEvent(new InputEvent("input", { bubbles: true, cancelable: true, composed: true, data: mapping.value }));
      editable.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      editable.blur();
      return Boolean((editable.textContent ?? "").trim());
    }
    return false;
  }
  let menuCloserBound = false;
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "STOP_AUTO_CONTINUE") {
      disableAutoContinueWatch();
      showToast("1-Apply stopped filling this page.");
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === "GET_PAGE_META") {
      const pageText = document.body?.innerText?.slice(0, 2e4) ?? "";
      sendResponse({
        type: "PAGE_META_RESULT",
        url: location.href,
        title: document.title,
        excerpt: pageText.slice(0, 4e3),
        pageText
      });
      return false;
    }
    if (message?.type === "INVENTORY") {
      const fields = inventoryFromDocument(document);
      const hazards = inspectPage(document, document.body?.innerText ?? "", fields);
      sendResponse({
        type: "INVENTORY_RESULT",
        fields,
        hazards,
        html: document.documentElement.outerHTML.slice(0, 2e4),
        url: location.href,
        title: document.title
      });
      return false;
    }
    if (message?.type === "CAPTURE_FILLED_STATE") {
      const fields = inventoryFromDocument(document);
      const captured = fields.map((field) => ({
        fieldKey: field.key,
        label: field.label || field.name || field.key,
        value: readControlValue(field.key, field.type),
        required: Boolean(field.required),
        fieldType: field.type
      }));
      const pageText = (document.body?.innerText ?? "").replace(/\s+/g, " ").trim().slice(0, 2e4);
      sendResponse({
        type: "CAPTURE_FILLED_STATE_RESULT",
        origin: location.origin,
        pageUrl: location.href,
        pageText,
        fields: captured
      });
      return false;
    }
    if (message?.type === "ATTACH_FILE_IN_FRAME") {
      const file = message.file;
      const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
      let ok = false;
      for (const input of inputs) {
        if (applyFile(input, file)) ok = true;
      }
      sendResponse({ ok });
      return false;
    }
    if (message?.type === "FILL" || message?.type === "APPLY_SUGGESTIONS" || message?.type === "APPLY_SUGGESTIONS") {
      assertFillActionAllowed("setValue");
      const expectedOrigin = String(message.origin ?? "");
      if (expectedOrigin && location.origin !== expectedOrigin) {
        sendResponse({ type: "FILL_RESULT", filled: [], error: "Origin mismatch" });
        return false;
      }
      void (async () => {
        root.__1APPLY_FILLING = true;
        try {
          inventoryFromDocument(document);
          clearChips();
          clearHighlights();
          const applicationId = String(message.applicationId ?? "");
          const results = [];
          const assisted = /* @__PURE__ */ new Set();
          for (const mapping of message.mappings ?? []) {
            const options = uniqueOptions(mapping.options, mapping.aiAnswerable ? "" : mapping.value);
            const el = findControl(mapping.fieldKey);
            if (!el) {
              results.push({ fieldKey: mapping.fieldKey, filled: false, skippedReason: "Control not found" });
              continue;
            }
            if (!fillTargetAllowed(mapping.fieldKey, mapping.type)) {
              results.push({ fieldKey: mapping.fieldKey, filled: false, skippedReason: "Protected control" });
              continue;
            }
            let filled = false;
            if (!mapping.aiAnswerable && (mapping.value || mapping.file?.base64)) {
              filled = await applyValue(el, mapping);
              if (!filled) {
                results.push({
                  fieldKey: mapping.fieldKey,
                  filled: false,
                  skippedReason: mapping.type === "file" ? "Could not attach file" : "Could not apply value"
                });
              }
            }
            const wantsAi = Boolean(mapping.aiAnswerable) || (mapping.type === "text" || mapping.type === "textarea" || mapping.type === "url" || mapping.type === "number" || mapping.type === "date") && !mapping.value && !mapping.file?.base64;
            if (wantsAi) {
              const question = mapping.label?.trim() || findCard(mapping.fieldKey)?.querySelector('[role="heading"]')?.textContent?.trim() || mapping.fieldKey;
              mountAiAssistant(el, mapping.fieldKey, question, mapping.type, applicationId, options);
              assisted.add(mapping.fieldKey);
              results.push({ fieldKey: mapping.fieldKey, filled: false, hasAlternates: true, skippedReason: "Awaiting AI Confirm" });
              continue;
            }
            if (options.length > 0 || mapping.showChip) {
              const chipOptions = options.length > 0 ? options : mapping.value ? [{ value: mapping.value, label: mapping.label || "Suggestion", source: "Application Memory" }] : [];
              if (chipOptions.length > 0) {
                mountChip(el, mapping.fieldKey, chipOptions, mapping.type);
                assisted.add(mapping.fieldKey);
              }
            }
            if (filled) {
              results.push({ fieldKey: mapping.fieldKey, filled: true, hasAlternates: options.length > 1 });
            } else if (options.length > 0 && !(mapping.value || mapping.file?.base64)) {
              results.push({ fieldKey: mapping.fieldKey, filled: false, hasAlternates: true, skippedReason: "Awaiting chip selection" });
            } else if (!(mapping.value || mapping.file?.base64)) {
              results.push({ fieldKey: mapping.fieldKey, filled: false, skippedReason: "Empty value" });
            }
          }
          const liveFields = inventoryFromDocument(document);
          for (const field of liveFields) {
            if (assisted.has(field.key)) continue;
            if (isProtectedControl(field) || isSensitiveField(field)) continue;
            const el = findControl(field.key);
            if (!el) continue;
            const card = findCard(field.key) || el;
            if (card.querySelector(`[${WIDGET_ATTR}]`)) continue;
            const choiceType = field.type === "radio" || field.type === "checkbox" || field.type === "select" || field.type === "multi-select";
            if (choiceType && field.options.length) {
              mountChip(
                el,
                field.key,
                field.options.map((value) => ({ value, label: field.label || "Form option", source: "Form choice" })),
                field.type
              );
              assisted.add(field.key);
              continue;
            }
            if (field.type === "text" || field.type === "textarea" || field.type === "url" || field.type === "number" || field.type === "date") {
              if (isControlFilled(field.key, el)) continue;
              mountAiAssistant(el, field.key, field.label || field.key, field.type, applicationId, []);
              assisted.add(field.key);
            }
          }
          const emailConsent = Array.from(document.querySelectorAll('[role="checkbox"]')).filter(
            (node) => /record\s+.+\s+as the email to be included with my response/i.test(
              `${node.getAttribute("aria-label") ?? ""} ${node.textContent ?? ""}`
            )
          );
          for (const box of emailConsent) {
            if (box.getAttribute("aria-checked") === "true") continue;
            activateToggle(box);
            await sleep(50);
            if (box.getAttribute("aria-checked") !== "true") activateToggle(box.parentElement);
            results.push({ fieldKey: "google-email-consent", filled: box.getAttribute("aria-checked") === "true" });
          }
          const highlightKeys = Array.isArray(message.highlightKeys) ? message.highlightKeys : (message.mappings ?? []).map((item) => item.fieldKey);
          highlightEmpty(highlightKeys);
          if (message.resumeFill) {
            root.__1APPLY_STOPPED = false;
          }
          if (message.autoContinue) {
            if (root.__1APPLY_STOPPED) {
              sendResponse({
                type: "FILL_RESULT",
                filled: results,
                highlighted: document.querySelectorAll(`[${APPLY_EMPTY_ATTR}]`).length,
                stopped: true
              });
              return;
            }
            enableAutoContinueWatch();
            root.__1APPLY_LAST_PAGE_FP = pageFingerprint();
            root.__1APPLY_CONTINUE_TRIES = 0;
            const filledCount = results.filter((item) => item.filled).length;
            showToast(filledCount ? `1-Apply filled ${filledCount} field(s).` : "1-Apply ready \u2014 tap 1A for AI questions.");
          }
          sendResponse({
            type: "FILL_RESULT",
            filled: results,
            highlighted: document.querySelectorAll(`[${APPLY_EMPTY_ATTR}]`).length
          });
        } finally {
          root.__1APPLY_FILLING = false;
        }
        if (message.autoContinue && isFillActive()) {
          await sleep(450);
          if (isFillActive()) await tryAutoAdvance();
        }
      })();
      return true;
    }
    return false;
  });
}
var clearPendingTimers2;
var trackTimeout2;
var isFillActive2;
var pageFingerprint2;
var showToast2;
var requestAutoContinue2;
var isStepAdvanceControlLocal2;
var scheduleAutoContinue2;
var enableAutoContinueWatch2;
var disableAutoContinueWatch2;
var cssEscape3;
var sleep2;
var findTagged2;
var findCard2;
var findControl2;
var readControlValue2;
var optionText2;
var setNativeTextValue2;
var base64ToFile2;
var normalizeFilename2;
var filenamesMatch2;
var fileAlreadyUploaded2;
var applyFile2;
var isTruthyCheckValue2;
var activateToggle2;
var isToggleChecked2;
var isControlFilled2;
var ensureHighlightStyle2;
var clearHighlights2;
var highlightEmpty2;
var clearChips2;
var ensureMenuCloser2;
var uniqueOptions2;
var closeAllAssistants2;
var mountAiAssistant2;
var mountChip2;
//# sourceMappingURL=content.js.map
