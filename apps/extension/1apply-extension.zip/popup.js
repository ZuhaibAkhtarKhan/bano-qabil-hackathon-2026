// ../../packages/domain/src/url-match.ts
function normalizeOpportunityUrl(raw) {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  try {
    const url = new URL(trimmed.includes("://") ? trimmed : `https://${trimmed}`);
    if (url.protocol !== "http:" && url.protocol !== "https:") return trimmed.toLowerCase();
    url.hash = "";
    url.hostname = url.hostname.replace(/^www\./i, "").toLowerCase();
    url.pathname = url.pathname.replace(/\/+$/, "") || "";
    const dropKeys = [];
    url.searchParams.forEach((_value, key) => {
      if (/^(utm_|ref$|fbclid|gclid)/i.test(key)) dropKeys.push(key);
    });
    for (const key of dropKeys) url.searchParams.delete(key);
    const search = url.searchParams.toString();
    return `${url.protocol}//${url.host}${url.pathname}${search ? `?${search}` : ""}`;
  } catch {
    return trimmed.replace(/\/+$/, "").toLowerCase();
  }
}
function urlPathIdentity(raw) {
  try {
    const url = new URL(normalizeOpportunityUrl(raw));
    const path = url.pathname.replace(/\/+$/, "") || "/";
    const formId = path.match(/\/forms\/d\/(?:e\/)?([^/]+)/)?.[1] ?? null;
    return { host: url.hostname, path, formId };
  } catch {
    return null;
  }
}
function scoreUrlMatch(pageUrl, savedUrl) {
  const a = normalizeOpportunityUrl(pageUrl);
  const b = normalizeOpportunityUrl(savedUrl);
  if (!a || !b) return 0;
  if (a === b) return 1;
  const left = urlPathIdentity(a);
  const right = urlPathIdentity(b);
  if (!left || !right || left.host !== right.host) return 0;
  if (left.path === right.path) return 0.95;
  if (left.formId && right.formId && left.formId === right.formId) return 0.92;
  if (left.path.startsWith(`${right.path}/`) || right.path.startsWith(`${left.path}/`)) return 0.85;
  const segsA = left.path.split("/").filter(Boolean);
  const segsB = right.path.split("/").filter(Boolean);
  let shared = 0;
  while (shared < segsA.length && shared < segsB.length && segsA[shared] === segsB[shared]) shared += 1;
  if (shared >= 2 && shared === Math.min(segsA.length, segsB.length)) return 0.8;
  return 0;
}
function matchApplicationByUrl(pageUrl, apps) {
  let best = null;
  for (const app of apps) {
    for (const candidate of [app.canonicalUrl, app.sourceUrl]) {
      if (!candidate) continue;
      const score = scoreUrlMatch(pageUrl, candidate);
      if (score >= 0.85 && (!best || score > best.score)) best = { app, score };
    }
  }
  return best?.app ?? null;
}

// src/popup/popup.ts
var statusEl = document.getElementById("status");
var sessionEl = document.getElementById("session");
var hazardEl = document.getElementById("hazard");
var logEl = document.getElementById("log");
var matchEl = document.getElementById("match");
var stopEl = document.getElementById("stop");
var applicationEl = document.getElementById("application");
var cachedApps = [];
function log(text) {
  logEl.textContent = text;
}
function send(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else if (response && typeof response === "object" && "error" in response && response.error)
        reject(new Error(response.error));
      else resolve(response);
    });
  });
}
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] ?? char);
}
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url) throw new Error("No active tab.");
  return tab;
}
async function ensureSiteAccessFromGesture(tabUrl) {
  const parsed = new URL(tabUrl);
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("Open a public http(s) page first.");
  }
  if (parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1" || parsed.hostname === "::1") {
    throw new Error("Local pages cannot be ingested or filled.");
  }
  const origins = [`${parsed.origin}/*`];
  const already = await chrome.permissions.contains({ origins });
  if (already) return parsed.origin;
  const granted = await chrome.permissions.request({ origins });
  if (!granted) {
    throw new Error("Allow access to this site so 1-Apply can fill it and continue on later steps.");
  }
  return parsed.origin;
}
function selectApplicationForUrl(pageUrl) {
  if (!pageUrl || !cachedApps.length) {
    matchEl.textContent = "";
    return null;
  }
  const matched = matchApplicationByUrl(pageUrl, cachedApps);
  if (matched) {
    applicationEl.value = matched.id;
    matchEl.textContent = `Matched from this page URL \xB7 ${matched.title}`;
    return matched;
  }
  matchEl.textContent = "No saved application matches this URL \u2014 Save to 1-Apply first, or pick one.";
  return null;
}
async function refreshFillSessionUi() {
  try {
    const session = await send({ type: "FILL_SESSION_STATUS" });
    if (session.active) {
      sessionEl.textContent = `Filling until you Stop or close the page${session.origin ? ` \xB7 ${session.origin}` : ""}.`;
      sessionEl.classList.remove("hidden");
      stopEl.classList.remove("hidden");
    } else {
      sessionEl.textContent = "";
      sessionEl.classList.add("hidden");
      stopEl.classList.add("hidden");
    }
  } catch {
    sessionEl.classList.add("hidden");
    stopEl.classList.add("hidden");
  }
}
async function refreshSession() {
  try {
    const session = await send({ type: "SESSION" });
    statusEl.textContent = `Connected as ${session.email}. After Fill, it keeps going on Next until you Stop.`;
    cachedApps = await send({ type: "LIST_APPLICATIONS" });
    applicationEl.innerHTML = cachedApps.map(
      (item) => `<option value="${item.id}">${escapeHtml(item.title)}${item.organization ? ` \xB7 ${escapeHtml(item.organization)}` : ""}</option>`
    ).join("");
    if (cachedApps.length === 0) {
      applicationEl.innerHTML = `<option value="">Save a page first</option>`;
      matchEl.textContent = "";
    } else {
      const tab = await activeTab().catch(() => null);
      selectApplicationForUrl(tab?.url ?? null);
    }
    await refreshFillSessionUi();
  } catch (error) {
    statusEl.textContent = error instanceof Error ? error.message : "Not connected. Sign in to 1-Apply, then Options \u2192 Connect with website session.";
    sessionEl.classList.add("hidden");
    stopEl.classList.add("hidden");
  }
}
document.getElementById("save").addEventListener("click", async () => {
  log("Saving current URL to 1-Apply\u2026");
  try {
    const tab = await activeTab();
    await ensureSiteAccessFromGesture(tab.url);
    const result = await send({ type: "SAVE_PAGE" });
    log(result.duplicate ? "This website is already added." : "Saved. Analysis will run in 1-Apply.");
    await refreshSession();
    if (result.applicationId) applicationEl.value = result.applicationId;
  } catch (error) {
    log(error instanceof Error ? error.message : "Save failed.");
  }
});
document.getElementById("fill").addEventListener("click", async () => {
  log("Filling matched fields from Application Memory\u2026");
  try {
    const tab = await activeTab();
    await ensureSiteAccessFromGesture(tab.url);
    const inventory = await send({ type: "SCAN_FORM" });
    const hazard = inventory.hazards;
    const messages = [hazard?.captchaMessage, hazard?.accountMessage, hazard?.unsupportedReason].filter(Boolean);
    hazardEl.textContent = messages.join(" ");
    hazardEl.classList.toggle("hidden", messages.length === 0);
    if (!cachedApps.length) {
      cachedApps = await send({ type: "LIST_APPLICATIONS" });
    }
    const matched = selectApplicationForUrl(inventory.url);
    const applicationId = matched?.id || applicationEl.value;
    if (!applicationId) {
      log("Save this page to 1-Apply first so we can match the application by URL.");
      return;
    }
    const plan = await send({
      type: "CREATE_FILL_PLAN",
      applicationId,
      origin: inventory.origin || new URL(inventory.url).origin,
      fields: inventory.fields,
      hazards: inventory.hazards
    });
    const result = await send({
      type: "APPLY_SUGGESTIONS",
      applicationId,
      fillSessionId: plan.fillSessionId,
      mappings: plan.mappings,
      highlightKeys: inventory.fields.map((field) => String(field.key ?? "")).filter(Boolean),
      origin: inventory.origin || new URL(inventory.url).origin,
      tabId: inventory.tabId
    });
    const filled = result.filled?.filter((item) => item.filled) ?? [];
    const chips = result.filled?.filter((item) => item.hasAlternates).length ?? 0;
    const highlighted = result.highlighted ?? 0;
    const aiCount = plan.mappings.filter((item) => item.aiAnswerable).length;
    log(
      `Filled ${filled.length}. Keeps filling after Next until you Stop. ${aiCount ? `${aiCount} AI assistant(s) \u2014 tap 1A on the page, Generate, Confirm. ` : ""}${chips && !aiCount ? `${chips} chip(s) for alternates. ` : ""}${highlighted ? `${highlighted} still empty \u2014 highlighted.` : "Submit remains yours."}`
    );
    await refreshFillSessionUi();
  } catch (error) {
    log(error instanceof Error ? error.message : "Fill failed.");
  }
});
stopEl.addEventListener("click", async () => {
  try {
    await send({ type: "STOP_FILL_SESSION" });
    log("Stopped. Values synced to Application Memory \u2014 1-Apply continues in the background.");
    await refreshFillSessionUi();
  } catch (error) {
    log(error instanceof Error ? error.message : "Could not stop.");
  }
});
document.getElementById("options").addEventListener("click", () => chrome.runtime.openOptionsPage());
applicationEl.addEventListener("change", () => {
  matchEl.textContent = "Using the application you selected.";
});
void refreshSession();
//# sourceMappingURL=popup.js.map
